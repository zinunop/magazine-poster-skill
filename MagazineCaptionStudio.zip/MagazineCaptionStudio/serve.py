# -*- coding: utf-8 -*-
"""本地图片排版服务：caption.py 是唯一排版引擎；默认端口 8801。"""
import atexit
import base64
import io
import json
import math
import os
import socket
import re
import secrets
import sys
import threading
import time
import traceback
import uuid
import webbrowser
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit

HERE = os.path.dirname(os.path.abspath(__file__))
WEB = os.path.join(HERE, "web")
TMP = os.path.join(HERE, ".tmp")
LOG = os.path.join(HERE, "serve.log")
sys.path.insert(0, HERE)
import caption


class _Tee:
    """把控制台输出同时写进日志文件，便于事后排查问题。"""

    def __init__(self, stream, handle):
        self.stream, self.handle = stream, handle

    def write(self, text):
        for target in (self.stream, self.handle):
            try:
                target.write(text)
            except Exception:
                pass
        return len(text)

    def flush(self):
        for target in (self.stream, self.handle):
            try:
                target.flush()
            except Exception:
                pass


def start_log():
    """开启日志：同一文件追加写，超过 512KB 时轮转一次为 serve.log.old。"""
    try:
        if os.path.isfile(LOG) and os.path.getsize(LOG) > 512 * 1024:
            os.replace(LOG, LOG + ".old")
        handle = open(LOG, "a", encoding="utf-8", errors="replace")
    except OSError as exc:
        print("[CaptionStudio] 日志文件无法写入：%s" % exc)
        return
    handle.write("\n===== %s  服务启动 =====\n" % time.strftime("%Y-%m-%d %H:%M:%S"))
    handle.flush()
    sys.stdout = _Tee(sys.stdout, handle)
    sys.stderr = _Tee(sys.stderr, handle)

_lock = threading.RLock()
_current_batch = None
_current_files = []
_owned = re.compile(r"(?:[0-9a-f]{10}(?:_out)?|[0-9a-f]{12}_\d{2})\.(?:png|jpg|html)$")


def cleanup(results_only=False, preserve_source=None):
    """只清理本工具在 .tmp 内创建的文件，绝不处理用户原始路径或下载。"""
    global _current_batch, _current_files
    if not os.path.isdir(TMP):
        return
    errors = []
    for name in os.listdir(TMP):
        if not _owned.fullmatch(name):
            continue
        is_source = re.fullmatch(r"[0-9a-f]{10}\.(png|jpg)", name)
        if results_only and is_source and (preserve_source is None or name == preserve_source):
            continue
        path = os.path.join(TMP, name)
        if os.path.isfile(path):
            try:
                os.remove(path)
            except OSError as exc:
                errors.append(str(exc))
    _current_batch, _current_files = None, []
    if errors:
        raise RuntimeError("临时文件清理失败：" + "; ".join(errors))


def exit_cleanup():
    with _lock:
        try:
            cleanup()
        except Exception as exc:
            print("[CaptionStudio]", exc)


def analyze(path):
    prompt = caption.read_prompt(path)
    meta = caption.read_meta(path)        # 出图流程写入的角色信息（老图为空）
    from PIL import Image
    with Image.open(path) as im:
        w, h = im.size
    return {"w": w, "h": h, "hasPrompt": bool(prompt), "hasMeta": bool(meta),
            "prompt": prompt[:4000],
            "title": (meta.get("title") or (caption.guess_title(prompt) if prompt else "")),
            "name": (meta.get("name") or (caption.guess_name(prompt) if prompt else "")),
            "item": (meta.get("item") or (caption.guess_item(prompt) or "") if prompt else ""),
            "colors": caption.extract_colors(path, 4),
            "person": [round(v, 4) for v in caption.person_bbox(path)]}


def number(data, key, default, low=0, high=100, integer=False):
    value = data.get(key)
    if value in (None, ""):
        value = default
    value = float(value)
    if not math.isfinite(value) or not low <= value <= high:
        raise ValueError("%s 必须在 %s～%s 之间" % (key, low, high))
    if integer and not value.is_integer():
        raise ValueError("%s 必须为整数" % key)
    return int(value) if integer else value


def render_options(data):
    opts = {key: data.get(key) for key in
            ("title", "name", "item", "item2", "brand", "kicker", "issue", "year", "foot",
             "ink", "colors", "bg")}
    for key in ("title", "name", "item", "item2", "brand", "kicker", "issue", "year", "foot"):
        if opts[key] is not None and (not isinstance(opts[key], str) or len(opts[key]) > 1000):
            raise ValueError("文字参数格式错误或过长")
    if isinstance(opts.get("colors"), str) and not opts["colors"].strip():
        opts["colors"] = None            # 空串 = 交给引擎自动取色
    if opts.get("bg") in (None, ""):
        opts["bg"] = None                # 空 = 用引擎默认背景色
    opts["density"] = number(data, "density", 1, high=6)
    for dest, lo, hi, defaults in (("n_line", "nline", "nline2", (4, 7)),
                                    ("n_shape", "nshape", "nshape2", (6, 10))):
        pair = (number(data, lo, defaults[0], high=60, integer=True),
                number(data, hi, defaults[1], high=60, integer=True))
        if pair[0] > pair[1]:
            raise ValueError("素材数量下限不能大于上限")
        opts[dest] = pair
    opts["pad"] = number(data, "pad", 20, high=300)
    opts["edge"] = None if data.get("edge") in (None, "") else number(data, "edge", 40, high=400)
    opts["row_boost"] = number(data, "rowboost", 1.55, high=6)
    bands = number(data, "bands", 3, high=15, integer=True)
    opts["n_bands"] = (bands, bands)
    opts["lw"] = number(data, "lw", 4, low=0, high=30, integer=True)
    opts["tsize"] = None if data.get("tsize") in (None, "") else number(data, "tsize", 136, low=1, high=800, integer=True)
    opts["toff"] = number(data, "toff", 0, low=-300, high=300)
    opts["toffx"] = number(data, "toffx", 0, low=-300, high=300)
    opts["dscale"] = number(data, "dscale", 1, low=0.2, high=3)
    opts["dalpha"] = number(data, "dalpha", 1, low=0.05, high=2)
    opts["safe"] = number(data, "safe", 0.16, low=0.02, high=0.35)
    opts["gap"] = number(data, "gap", 14, low=0, high=80)
    opts["grid"] = (number(data, "gridc", 4, low=2, high=10, integer=True),
                    number(data, "gridr", 5, low=2, high=10, integer=True))
    font = data.get("font")
    if font not in (None, "", "georgia", "sourcehan"):
        raise ValueError("字体选项不正确")
    opts["font"] = None if font in (None, "") else font
    zone = data.get("zone")
    if zone not in (None, "", "random", "left", "right", "bottom", "leftbottom"):
        raise ValueError("标题区域不正确")
    opts["zone"] = None if zone in (None, "", "random") else zone
    preset = data.get("preset")
    if preset not in (None, ""):
        if not isinstance(preset, str) or not re.fullmatch(r"[A-Za-z0-9_\-]{1,40}", preset):
            raise ValueError("预设名称不正确")
    opts["preset"] = None if preset in (None, "") else preset
    # 元件表覆写：{元件id: {字段: 值}} —— 前端面板改的就是这些
    ov = data.get("overrides")
    if ov is not None:
        if not isinstance(ov, dict) or len(ov) > 200:
            raise ValueError("覆写参数格式错误")
        clean = {}
        for eid, patch in ov.items():
            if not isinstance(eid, str) or not eid or len(eid) > 60 or not isinstance(patch, dict):
                raise ValueError("覆写参数格式错误")
            if len(json.dumps(patch, ensure_ascii=False)) > 4000:
                raise ValueError("单个元件的覆写内容过大")
            clean[eid] = patch
        ov = clean
    opts["overrides"] = ov
    return opts


def resolve_source(tid):
    """按上传标识找到 .tmp 里的源图路径；找不到抛错。"""
    if not isinstance(tid, str) or not re.fullmatch(r"[0-9a-f]{10}", tid):
        raise ValueError("图片标识无效，请重新上传")
    for ext in (".png", ".jpg"):
        path = os.path.join(TMP, tid + ext)
        if os.path.isfile(path):
            return path
    raise ValueError("图片不存在，请重新上传")


class Handler(BaseHTTPRequestHandler):
    server_version = "CaptionStudio/2.0"

    def log_message(self, fmt, *args):
        pass

    def _send(self, code, body, ctype="application/json; charset=utf-8", filename=None):
        if isinstance(body, (dict, list)):
            body = json.dumps(body, ensure_ascii=False).encode("utf-8")
        elif isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        if filename:
            self.send_header("Content-Disposition", 'attachment; filename="%s"' % filename)
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, TimeoutError):
            pass

    def do_GET(self):
        global _current_batch
        url = urlsplit(self.path)
        p = url.path
        if p in ("/", "/index.html"):
            with open(os.path.join(WEB, "index.html"), "rb") as f:
                return self._send(200, f.read(), "text/html; charset=utf-8")
        if p == "/api/ping":
            return self._send(200, {"ok": True, "version": 2})
        if p == "/api/presets":
            items = []
            for item in caption.list_presets():
                pre = caption.load_preset(item["id"])
                items.append(dict(item, **caption.preset_ui_defaults(pre),
                                  hasElements=bool(pre.get("elements")),
                                  ui=pre.get("ui")))
            return self._send(200, {"ok": True, "presets": items})
        if p == "/api/preset":
            pid = parse_qs(url.query).get("id", [""])[0]
            pre = caption.load_preset(pid)
            return self._send(200, {"ok": True, "id": pre.get("id"),
                                    "ui": pre.get("ui"),
                                    "elements": pre.get("elements") or [],
                                    "texts": pre.get("texts") or {},
                                    "switches": pre.get("switches") or {},
                                    # 配色数量由预设自己定 → 面板里的「主色N」选项跟着它走
                                    "ncolors": int((pre.get("palette") or {}).get("count") or 4)})
        if p == "/api/download":
            batch = parse_qs(url.query).get("batch", [""])[0]
            with _lock:
                if not batch or batch != _current_batch or not _current_files:
                    return self._send(410, {"ok": False, "error": "这批图片已清理，请下载当前批次"})
                buf = io.BytesIO()
                with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_STORED) as archive:
                    for file in _current_files:
                        archive.write(file, os.path.basename(file))
                return self._send(200, buf.getvalue(), "application/zip", "caption_" + batch + ".zip")
        if p.startswith("/files/"):
            name = p[7:]
            if _owned.fullmatch(name) and name.endswith((".png", ".jpg")):
                with _lock:
                    fp = os.path.join(TMP, name)
                    if os.path.isfile(fp):
                        with open(fp, "rb") as f:
                            return self._send(200, f.read(),
                                              "image/jpeg" if name.endswith(".jpg") else "image/png")
        return self._send(404, {"ok": False, "error": "not found"})

    def do_POST(self):
        global _current_batch, _current_files
        # 只供同一台电脑操作，阻止外部网站触发本地生成/关闭。
        origin = self.headers.get("Origin")
        if origin and origin not in ("http://127.0.0.1:%d" % self.server.server_port,
                                      "http://localhost:%d" % self.server.server_port):
            return self._send(403, {"ok": False, "error": "只接受本地网页请求"})
        try:
            n = int(self.headers.get("Content-Length", "0"))
            if not 0 <= n <= 80 * 1024 * 1024:
                raise ValueError("上传数据过大")
            data = json.loads(self.rfile.read(n).decode("utf-8")) if n else {}
            if not isinstance(data, dict):
                raise ValueError("参数必须为对象")
        except Exception as exc:
            return self._send(400, {"ok": False, "error": "参数解析失败：" + str(exc)})
        p = urlsplit(self.path).path
        try:
            if p == "/api/analyze":
                raw = base64.b64decode(data.get("image", "").split(",", 1)[-1], validate=True)
                from PIL import Image
                with Image.open(io.BytesIO(raw)) as im:
                    im.verify()
                tid = uuid.uuid4().hex[:10]
                ext = ".jpg" if raw[:2] == b"\xff\xd8" else ".png"
                with _lock:
                    fp = os.path.join(TMP, tid + ext)
                    try:
                        with open(fp, "wb") as f:
                            f.write(raw)
                        info = analyze(fp)
                    except Exception:
                        if os.path.exists(fp):
                            os.remove(fp)
                        raise
                    previous = data.get("previousId", "")
                    if isinstance(previous, str) and re.fullmatch(r"[0-9a-f]{10}", previous):
                        for suffix in (".png", ".jpg"):
                            old = os.path.join(TMP, previous + suffix)
                            if os.path.isfile(old):
                                os.remove(old)
                    print("[CaptionStudio] 已载入图片 %sx%s，配色 %s"
                          % (info["w"], info["h"], ",".join(info["colors"])), flush=True)
                    return self._send(200, dict(info, ok=True, id=tid, ext=ext))
            if p == "/api/preview":
                # 只生成排版 HTML，不截图 → 前端 iframe 直接显示，改参数即时反馈。
                options = render_options(data)
                seed_value = data.get("seed")
                options["seed"] = (secrets.randbits(48) if seed_value in (None, "")
                                   else number(data, "seed", 0, low=0, high=2**53, integer=True))
                with _lock:
                    src = resolve_source(data.get("id", ""))
                    host = self.headers.get("Host") or ("127.0.0.1:%d" % self.server.server_port)
                    options["img_src"] = "http://%s/files/%s" % (host, os.path.basename(src))
                    html, w, h, _meta = caption.build_page(src, **options)
                return self._send(200, {"ok": True, "html": html, "w": w, "h": h})
            if p == "/api/render":
                tid = data.get("id", "")
                if not isinstance(tid, str) or not re.fullmatch(r"[0-9a-f]{10}", tid):
                    raise ValueError("图片标识无效，请重新上传")
                count = number(data, "count", 2, low=1, high=20, integer=True)
                options = render_options(data)
                seed_value = data.get("seed")
                seed = secrets.randbits(48) if seed_value in (None, "") else number(data, "seed", 0, low=0, high=2**53-count, integer=True)
                with _lock:
                    src = resolve_source(tid)
                    # 下一次生成清除上一批 PNG/HTML，保留上传图供继续调参。
                    cleanup(results_only=True, preserve_source=os.path.basename(src))
                    batch = uuid.uuid4().hex[:12]
                    images, files = [], []
                    try:
                        for i in range(count):
                            out = os.path.join(TMP, "%s_%02d.png" % (batch, i + 1))
                            actual_seed = seed + i
                            caption.render(src, out, seed=actual_seed, **options)
                            with open(out, "rb") as f:
                                b64 = base64.b64encode(f.read()).decode("ascii")
                            images.append({"image": "data:image/png;base64," + b64,
                                           "file": "/files/" + os.path.basename(out),
                                           "seed": actual_seed, "index": i + 1})
                            files.append(out)
                    except Exception:
                        cleanup(results_only=True)
                        raise
                    _current_batch, _current_files = batch, files
                    print("[CaptionStudio] 已生成 %d 张（种子 %s 起，配色 %s）"
                          % (count, seed, options.get("colors") or "自动"), flush=True)
                    return self._send(200, dict(images[0], ok=True, images=images, count=count, batch=batch))
            if p == "/api/shutdown":
                self._send(200, {"ok": True})
                threading.Thread(target=self.server.shutdown, daemon=True).start()
                return
            return self._send(404, {"ok": False, "error": "not found"})
        except (ValueError, TypeError) as exc:
            print("[CaptionStudio] 参数错误：%s" % exc)
            return self._send(400, {"ok": False, "error": str(exc)})
        except Exception as exc:
            print("[CaptionStudio] 处理 %s 失败：%s" % (p, exc))
            if isinstance(data, dict):
                print("[CaptionStudio] 请求参数：%r"
                      % ({k: v for k, v in data.items() if k != "image"},))
            traceback.print_exc()
            return self._send(500, {"ok": False, "error": str(exc)})


class Server(ThreadingHTTPServer):
    daemon_threads = False
    block_on_close = True
    allow_reuse_address = False

    def server_bind(self):
        if hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        super().server_bind()

    def get_request(self):
        connection, address = super().get_request()
        connection.settimeout(30)
        return connection, address


def main():
    port = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1] != "--no-browser" else 8801
    os.makedirs(TMP, exist_ok=True)
    start_log()
    # 先占用端口再清理，避免第二个服务误清正在使用的产物。
    server = Server(("127.0.0.1", port), Handler)
    try:
        with _lock:
            cleanup()
        print("[CaptionStudio] http://127.0.0.1:%d/" % port, flush=True)
        print("[CaptionStudio] 日志文件：%s" % LOG, flush=True)
        if "--no-browser" not in sys.argv:
            webbrowser.open("http://127.0.0.1:%d/" % port)
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
        exit_cleanup()
        print("[CaptionStudio] 已停止，临时文件已清理", flush=True)


if __name__ == "__main__":
    main()

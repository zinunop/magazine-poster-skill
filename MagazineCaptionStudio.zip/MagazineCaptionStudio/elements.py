# -*- coding: utf-8 -*-
"""元件表渲染器 —— 数据驱动版式（A+ 架构的 L1 层）

**一个预设 = 一组元件（JSON 数组）。** 本模块把元件表渲染成 CSS + HTML。

与老模板（`caption.py` 的 `TPL`）**完全独立**：只有预设里出现 `"elements"` 字段时才走这里，
所以老预设（magazine-poster-01）一个字节都不受影响。

七种元件
--------
image  图片层（原图 / 抠图人物层）
text   文字（多行 / 竖排 / 描边 / 阴影）
rect   矩形（色块 / 垫底块 / 竖条）
line   线
scrim  渐变遮罩
decor  装饰（复用老引擎的 17 种，由调用方通过 ctx['decor_fn'] 提供）
group  组合（含子元件，可整体定位）

定位：`anchor`（九宫格）+ `offset`（从那个角往里挪多少）。
也支持直接写百分比 —— 因为九宫格本来就是百分比的语法糖。

颜色（`color` / `fill` 字段）四种写法
-----------------------------------
"#16263f"                       固定色
"ink" / "c1" ~ "cN"             引用调色板
{"mode":"global","shift":0.6}   取**整图背景色**，shift 正=提亮、负=加深
{"mode":"local","auto":true}    取**文字背后那块**的底色，自动明暗
{"mode":"local","shift":-0.35}  同上但固定加深 35%

随机（`random` 字段）
--------------------
0.5                              出现概率（一半机会出现）
{"opacity": [0.7, 1.0]}          区间随机
{"offset": [[38,0],[52,0]]}      候选随机
{"style": {"font-size": ["90px","110px"]}}  嵌套字段随机
"""
import re

ELEMENT_TYPES = ('image', 'text', 'rect', 'line', 'scrim', 'decor', 'group',
                 'title', 'bands')

ANCHORS = ('top-left', 'top', 'top-right', 'left', 'center', 'right',
           'bottom-left', 'bottom', 'bottom-right')

COMMON_DEFAULTS = {
    'anchor': 'top-left', 'offset': [0, 0], 'size': 'auto', 'z': None,
    'opacity': 1, 'visible': True, 'random': None, 'style': {}, 'class': '',
}

TYPE_DEFAULTS = {
    'image': {'src': 'base', 'fit': 'cover'},
    'text': {'content': '', 'font': 'sans', 'align': 'left', 'writing_mode': 'horizontal',
             'color': 'ink', 'letter_spacing': 0, 'line_height': 1.15, 'weight': 400,
             'stroke': None, 'shadow': None},
    'rect': {'fill': 'ink', 'radius': 0, 'border': None},
    'line': {'orient': 'h', 'thickness': '1px', 'fill': 'ink'},
    'scrim': {'from': 'rgba(0,0,0,0)', 'to': 'rgba(0,0,0,.6)', 'angle': 0, 'stops': None},
    'decor': {'pool': None, 'count': [4, 7], 'color': 'person', 'area': None},
    'group': {'children': [], 'layout': 'absolute'},
}

FONT_STACKS = {
    'serif': "Georgia,'Times New Roman',serif",
    'sans': "'Helvetica Neue',Arial,sans-serif",
}


# ---------- 小工具 ----------
def to_px(value, W, H=None, default=0.0, axis='x'):
    """把 '12px' / '5.8vw' / '22.7vh' / '3%' / 12 这类写法换算成像素。

    基准分三种，别搞混：
      `vw` 永远按宽度算，`vh` 永远按高度算；
      `%` 按**所在方向**算 —— 给宽度用的按宽度、给高度用的按高度（`axis` 决定）。
      ⚠️ 把 `%` 一刀切成"按宽度算"会让 `height:"100%"` 变成 720px（图被压扁），实测踩过。
    """
    if value is None:
        return default
    if isinstance(value, (int, float)):
        return float(value)
    m = re.fullmatch(r'\s*(-?[0-9.]+)\s*(px|vw|vh|%)?\s*', str(value))
    if not m:
        return default
    num, unit = float(m.group(1)), (m.group(2) or 'px')
    if unit == 'px':
        return num
    if unit == 'vh':
        return (H if H is not None else W) * num / 100.0
    if unit == 'vw':
        return W * num / 100.0
    base = (H if H is not None else W) if axis == 'y' else W
    return base * num / 100.0


def hex_of(rgb):
    return '#%02x%02x%02x' % tuple(int(max(0, min(255, v))) for v in rgb)


def shift_color(rgb, amount):
    """amount > 0 提亮（朝白靠），< 0 加深（朝黑靠）。纯 Python，不依赖 numpy。"""
    out = []
    for v in rgb:
        v = float(v)
        out.append(v + (255.0 - v) * amount if amount >= 0 else v * (1.0 + amount))
    return out


def luminance(rgb):
    return 0.299 * float(rgb[0]) + 0.587 * float(rgb[1]) + 0.114 * float(rgb[2])


def when_ok(spec, switches):
    """元件 / 候选上的 `"when": "name"` 或 `"!name"` —— 按预设声明的开关决定去留。

    预设里写 `"switches": {"dark": 0.55}`，引擎每次渲染掷一次骰子得到开关值；
    元素与颜色候选都能挂 `when` 跟着它走。
    （这就是"有压暗层 → 用全局加亮；没压暗层 → 用逐块"的配对实现。）
    """
    if not spec:
        return True
    name = str(spec)
    neg = name.startswith('!')
    val = bool(switches.get(name[1:] if neg else name, False))
    return (not val) if neg else val


def choose(spec, ctx):
    """颜色字段写成列表时 = **候选池**，每次渲染随机抽一个。

    这就是"取色策略随机池"：
        "color": [{"mode":"global","shift":0.6}, {"mode":"local","auto":true}]
    候选可以带 `when`，先按开关过滤再抽 —— 例如：
        [{"mode":"global","shift":0.62,"when":"dark"}, {"mode":"local","auto":true,"when":"!dark"}]
    """
    if isinstance(spec, list) and spec:
        sw = ctx.get('switches') or {}
        pool = [x for x in spec
                if not (isinstance(x, dict) and x.get('when') and not when_ok(x['when'], sw))]
        return ctx['rng'].choice(pool or spec)
    return spec


def apply_overrides(elements, overrides):
    """把前端传来的改动按元件 `id` 合并进元件表（`style` 做浅合并，其余直接覆盖）。"""
    if not overrides or not isinstance(overrides, dict):
        return elements
    out = []
    for el in elements:
        ov = overrides.get(el.get('id'))
        if not ov or not isinstance(ov, dict):
            out.append(el)
            continue
        merged = dict(el)
        for k, v in ov.items():
            if k == 'style' and isinstance(v, dict):
                merged['style'] = dict(merged.get('style') or {}, **v)
            else:
                merged[k] = v
        out.append(merged)
    return out


def rand_value(rng, spec):
    """random 字段里的一个值：候选列表 / 区间 / 原样。"""
    if not isinstance(spec, list) or not spec:
        return spec
    if isinstance(spec[0], list):                       # [[a,b],[c,d]] → 候选
        return list(rng.choice(spec))
    if len(spec) == 2 and all(isinstance(v, (int, float)) for v in spec):
        return rng.uniform(spec[0], spec[1])            # [lo, hi] → 区间
    return rng.choice(spec)                             # 其他列表 → 候选


def apply_random(el, rng):
    """按 random 字段决定「出不出现」并随机化字段。返回 (元件, 是否渲染)。

    三种写法：
        "random": 0.5                                    → 一半概率出现
        "random": {"offset": [[38,206],[42,212]]}        → 位置在候选里抽
        "random": {"chance": 0.5, "style": {...}}        → **既有出现概率、又能随机字段**
    """
    r = el.get('random')
    if r is None:
        return el, True
    if isinstance(r, (int, float)) and not isinstance(r, bool):
        return el, rng.random() < float(r)
    if not isinstance(r, dict):
        return el, True
    out = dict(el)
    if 'chance' in r and rng.random() >= float(r['chance']):
        return el, False
    for field, spec in r.items():
        if field == 'chance':
            continue
        if field == 'style' and isinstance(spec, dict):
            merged = dict(out.get('style') or {})
            for k, v in spec.items():
                merged[k] = rand_value(rng, v)
            out['style'] = merged
        else:
            out[field] = rand_value(rng, spec)
    return out, True


def anchor_css(anchor, offset, W, H):
    """九宫格锚点 + 偏移 → 定位用的 CSS。"""
    anchor = anchor if anchor in ANCHORS else 'top-left'
    x, y = (offset + [0, 0])[:2] if isinstance(offset, list) else (0, 0)
    x = to_px(x, W, H)
    y = to_px(y, W, H, 0.0, 'y')
    parts, tf = [], []
    if anchor.endswith('left'):
        parts.append('left:%.2fpx' % x)
    elif anchor.endswith('right'):
        parts.append('right:%.2fpx' % x)
    else:
        parts.append('left:50%')
        tf.append('translateX(-50%)')
        if x:
            parts.append('margin-left:%.2fpx' % x)
    if anchor.startswith('top'):
        parts.append('top:%.2fpx' % y)
    elif anchor.startswith('bottom'):
        parts.append('bottom:%.2fpx' % y)
    else:
        parts.append('top:50%')
        tf.append('translateY(-50%)')
        if y:
            parts.append('margin-top:%.2fpx' % y)
    if tf:
        parts.append('transform:' + ' '.join(tf))
    return ';'.join(parts)


def size_css(size, W, H):
    """size → width/height。'auto' 或缺失则不写（交给内容撑开）。"""
    if size in (None, 'auto'):
        return ''
    if isinstance(size, (list, tuple)) and len(size) == 2:
        w, h = size
        out = []
        if w not in (None, 'auto'):
            out.append('width:%.2fpx' % to_px(w, W, H))
        if h not in (None, 'auto'):
            out.append('height:%.2fpx' % to_px(h, W, H, 0.0, 'y'))
        return ';'.join(out)
    return ''


def style_text(style):
    if not style:
        return ''
    return ';'.join('%s:%s' % (k, v) for k, v in style.items())


def element_box(el, W, H):
    """估算元件占据的像素框（局部取色要用）。文字按字号与行数估。"""
    size = el.get('size')
    if size not in (None, 'auto'):
        w = to_px(size[0], W, H) if size[0] not in (None, 'auto') else None
        h = to_px(size[1], W, H, 0.0, 'y') if size[1] not in (None, 'auto') else None
    else:
        w = h = None
    if el.get('type') == 'text' and (w is None or h is None):
        fs = to_px(el.get('style', {}).get('font-size'), W, H, H * 0.03, 'y')
        lines = str(el.get('content', '')).split('\n')
        if w is None:
            w = max(len(x) for x in lines) * fs * 0.62
        if h is None:
            h = len(lines) * fs * float(el.get('line_height', 1.15))
    if w is None:
        w = W
    if h is None:
        h = H * 0.12
    anchor = el.get('anchor', 'top-left')
    off = el.get('offset') or [0, 0]
    x = to_px(off[0], W, H)
    y = to_px(off[1], W, H, 0.0, 'y')
    if anchor.endswith('right'):
        x = W - x - w
    elif not anchor.endswith('left'):
        x = W / 2 - w / 2 + x
    if anchor.startswith('bottom'):
        y = H - y - h
    elif not anchor.startswith('top'):
        y = H / 2 - h / 2 + y
    return [x, y, w, h]


# ---------- 颜色 ----------
def resolve_color(spec, ctx, box=None):
    """把 color / fill 字段解析成 CSS 颜色。"""
    if spec is None:
        return ctx['ink']
    if isinstance(spec, str):
        if spec == 'ink':
            return ctx['ink']
        m = re.fullmatch(r'c([0-9]{1,2})', spec)
        if m:
            idx = int(m.group(1)) - 1
            cols = ctx['colors']
            return cols[idx] if idx < len(cols) else ctx['ink']
        return spec
    if not isinstance(spec, dict):
        return ctx['ink']

    fallback = spec.get('fallback') or ctx['ink']
    mode = spec.get('mode', 'local')
    extra = float(ctx.get('color_shift') or 0)               # 面板上的「整体提亮/加深」
    rgb = None
    if mode == 'global':
        rgb = ctx['bg_rgb']                                  # 整图背景色（四角中位数）
        amount = spec.get('shift', 0.6) + extra
    else:
        rgb = ctx['sample'](box)                             # 文字背后那块
        if spec.get('auto', True):
            amount = spec.get('amount', 0.62)
            amount = amount if luminance(rgb) <= 128 else -amount
            amount += extra
        else:
            amount = spec.get('shift', -0.35) + extra
    if rgb is None:
        return fallback
    return hex_of(shift_color(rgb, amount))


# ---------- 单个元件 ----------
def render_one(el, ctx, cls):
    """渲染一个元件，返回 (css 规则, html)。"""
    t = el.get('type')
    W, H = ctx['W'], ctx['H']
    if el.get('inset') is not None:                       # inset：四边内缩（画框/满版层用）
        v = to_px(el['inset'], W, H)
        pos = 'left:%.2fpx;top:%.2fpx;right:%.2fpx;bottom:%.2fpx' % (v, v, v, v)
    else:
        pos = anchor_css(el.get('anchor', 'top-left'), el.get('offset') or [0, 0], W, H)
    size = size_css(el.get('size'), W, H)
    extra = style_text(el.get('style'))
    common = ';'.join(x for x in ('position:absolute', pos, size, extra) if x)
    opacity = el.get('opacity', 1)
    if opacity != 1:
        common += ';opacity:%s' % opacity
    if el.get('class'):
        common += ';'

    if t == 'image':
        src = ctx['img_src']
        if el.get('src') == 'cutout':
            if not ctx.get('cutout_uri'):
                return '', ''                                # 抠图不可用 → 该层不渲染
            src = ctx['img_src']
            mask = ctx['cutout_uri']
            common += (';-webkit-mask-image:url(%s);-webkit-mask-size:100%% 100%%;'
                       'mask-image:url(%s);mask-size:100%% 100%%' % (mask, mask))
        fit = el.get('fit', 'cover')
        common += ';object-fit:%s' % fit
        return ('.%s{%s}' % (cls, common),
                '<img class="%s%s" src="%s">' % (cls, ' ' + el['class'] if el.get('class') else '', src))

    if t == 'text':
        color = resolve_color(choose(el.get('color', 'ink'), ctx), ctx, element_box(el, W, H))
        css = [common, 'color:%s' % color,
               'font-family:%s' % FONT_STACKS.get(el.get('font', 'sans'), el.get('font')),
               'font-weight:%s' % el.get('weight', 400),
               'line-height:%s' % el.get('line_height', 1.15)]
        if el.get('align', 'left') != 'left':
            css.append('text-align:%s' % el['align'])
        if el.get('letter_spacing'):
            css.append('letter-spacing:%s' % (
                el['letter_spacing'] if isinstance(el['letter_spacing'], str)
                else '%.2fpx' % el['letter_spacing']))
        if el.get('writing_mode') == 'vertical':
            css.append('writing-mode:vertical-rl')
        st = el.get('stroke')
        if st:
            css.append('-webkit-text-stroke:%s %s'
                       % (st.get('width', 2) if isinstance(st.get('width'), str)
                          else '%.1fpx' % st.get('width', 2), st.get('color', 'rgba(0,0,0,.5)')))
        sh = el.get('shadow')
        if sh:
            css.append('text-shadow:%s %s %s %s' % (
                sh.get('x', 0), sh.get('y', 4),
                sh.get('blur', 12) if isinstance(sh.get('blur'), str) else '%.0fpx' % sh.get('blur', 12),
                sh.get('color', 'rgba(0,0,0,.5)')))
        content = ctx['subst'](el.get('content', '')).replace('\n', '<br>')
        return ('.%s{%s}' % (cls, ';'.join(css)),
                '<div class="%s">%s</div>' % (cls, content))

    if t == 'rect':
        fill = resolve_color(choose(el.get('fill', 'ink'), ctx), ctx, element_box(el, W, H))
        css = [common, 'background:%s' % fill]
        if el.get('radius'):
            css.append('border-radius:%spx' % el['radius'])
        b = el.get('border')
        if b:
            css.append('border:%s solid %s' % (
                b.get('width', 1) if isinstance(b.get('width'), str) else '%.1fpx' % b.get('width', 1),
                b.get('color', 'rgba(0,0,0,.15)')))
        return '.%s{%s}' % (cls, ';'.join(css)), '<div class="%s"></div>' % cls

    if t == 'line':
        fill = resolve_color(choose(el.get('fill', 'ink'), ctx), ctx, element_box(el, W, H))
        th = el.get('thickness', '1px')
        th = th if isinstance(th, str) else '%.2fpx' % th
        if el.get('orient', 'h') == 'v':
            css = [common, 'width:%s' % th, 'background:%s' % fill]
        else:
            css = [common, 'height:%s' % th, 'background:%s' % fill]
        return '.%s{%s}' % (cls, ';'.join(css)), '<div class="%s"></div>' % cls

    if t == 'scrim':
        sub = ctx.get('subst') or (lambda x: x)
        stops = el.get('stops')
        if stops:
            body = ','.join('%s %s' % (sub(c), p if isinstance(p, str) else '%d%%' % round(p * 100))
                            for p, c in [(s[0], s[1]) for s in stops])
        else:
            body = '%s,%s' % (sub(el.get('from', 'rgba(0,0,0,0)')),
                              sub(el.get('to', 'rgba(0,0,0,.6)')))
        ang = el.get('angle', 0)
        css = [common, 'background:linear-gradient(%sdeg,%s)' % (ang, body)]
        return '.%s{%s}' % (cls, ';'.join(css)), '<div class="%s"></div>' % cls

    if t == 'decor':
        fn = ctx.get('decor_fn')
        if not fn:
            return '', ''
        css, html = fn(el, ctx)
        return css, html

    # 下面两种是「委派型」：布局仍是数据（写在哪、多大多小），但内部生成复用老引擎的
    # 标题样式池 / 斜色带算法 —— 这样迁移老预设时观感不会丢。
    if t == 'title':
        fn = ctx.get('title_fn')
        return fn(el, ctx) if fn else ('', '')

    if t == 'bands':
        fn = ctx.get('bands_fn')
        return fn(el, ctx) if fn else ('', '')

    if t == 'group':
        inner_css, inner_html = [], []
        for i, child in enumerate(el.get('children') or []):
            c_el, ok = apply_random(child, ctx['rng'])
            if not ok:
                continue
            sub_cls = '%s_%d' % (cls, i)
            if el.get('layout') == 'stack' and i:
                c_el = dict(c_el)
                c_el.setdefault('style', {})
            c, h = render_one(c_el, ctx, sub_cls)
            inner_css.append(c)
            inner_html.append(h)
        wrap = '.%s{%s}' % (cls, common)
        if el.get('layout') == 'stack':
            wrap += '.%s>*{position:relative!important;left:auto!important;top:auto!important;' \
                    'right:auto!important;bottom:auto!important;transform:none!important}' % cls
        return ' '.join([wrap] + inner_css), '<div class="%s">%s</div>' % (cls, ''.join(inner_html))

    return '', ''


def render(elements, ctx, overrides=None):
    """渲染整张元件表，返回 (css, html)。按 z 排序（没有 z 就按书写顺序）。"""
    ctx = dict(ctx)
    ctx.setdefault('rng', __import__('random').Random())
    # 面板上的「全局」覆写：__global.random_off = 关掉随机（调参用）；__global.color_shift = 整体提亮/加深
    g = (overrides or {}).get('__global') or {}
    elements = apply_overrides(elements or [], overrides)
    if g.get('random_off'):
        elements = [dict(el, random=None) for el in elements]
        ctx['switches'] = {k: False for k in (ctx.get('switches') or {})}
    else:
        # 预设声明的开关：每次渲染掷一次骰子，元素与颜色候选都能用 `when` 跟着它走
        # 面板可以覆写概率（__global.switches = {"dark": 0.55}）
        sw = g.get('switches') or (ctx.get('switches') or {})
        ctx['switches'] = {k: (ctx['rng'].random() < float(v)) for k, v in sw.items()}
    ctx['color_shift'] = g.get('color_shift') or 0
    items = []
    for i, el in enumerate(elements):
        if not when_ok(el.get('when'), ctx['switches']):
            continue
        el2, ok = apply_random(el, ctx['rng'])
        if not ok or not el2.get('visible', True):
            continue
        if el2.get('type') not in ELEMENT_TYPES:
            raise ValueError('未知元件类型：%r（可用：%s）' % (el2.get('type'), '/'.join(ELEMENT_TYPES)))
        items.append((el2.get('z'), i, el2))

    css, html = [], []
    # 绘制顺序 = 层级顺序：没写 z 的先画（按书写顺序，在最下面），写了 z 的按 z 升序后画。
    # ⚠️ 别把键写成 (x[0] is None, ...) —— 那样带 z 的会排到最前面（最底层），
    #    z=10 的人物层反而被底图盖住，"人物压住刊头"直接失效。实测踩过。
    order = sorted(items, key=lambda x: (0 if x[0] is None else 1, x[0] or 0, x[1]))
    for n, (_, _, el) in enumerate(order, 1):
        c, h = render_one(el, ctx, 'el%d' % n)
        if c:
            css.append(c)
        if h:
            html.append(h)
    return '\n'.join(css), '\n'.join(html)


def page(css, html, W, H, bg='#e9dfcb'):
    """把渲染结果包成完整 HTML 页。"""
    return ('<!DOCTYPE html><html><head><meta charset="utf-8"><style>\n'
            '*{margin:0;padding:0;box-sizing:border-box}\n'
            'html,body{width:%dpx;height:%dpx;overflow:hidden;background:%s}\n'
            '.canvas{position:relative;width:%dpx;height:%dpx}\n'
            '%s\n</style></head><body><div class="canvas">\n%s\n</div></body></html>'
            % (W, H, bg, W, H, css, html))

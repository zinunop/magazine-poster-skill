@echo off
setlocal enabledelayedexpansion
title Magazine Caption Studio
cd /d "%~dp0"

set "PORT=%~1"
if "%PORT%"=="" set "PORT=8801"

echo ================================================================
echo   Magazine Caption Studio
echo ================================================================
echo.

netstat -ano | findstr /r /c:":%PORT% .*LISTENING" >nul 2>&1
if not errorlevel 1 (
  echo       Already running on port %PORT%.
  echo       Opening the browser ...
  start "" "http://127.0.0.1:%PORT%/"
  ping -n 3 127.0.0.1 >nul
  exit /b 0
)

echo [1/3] Looking for a Python interpreter with Pillow ...
set "PYEXE="
set "PLAINPY="

rem --- 1) portable Python shipped next to this file ---
if exist "%~dp0python\python.exe" (
  set "PLAINPY="%~dp0python\python.exe""
  "%~dp0python\python.exe" -c "import PIL" >nul 2>&1
  if not errorlevel 1 set "PYEXE="%~dp0python\python.exe""
)

rem --- 2) explicit path listed in python-path.txt (optional, first line) ---
if not defined PLAINPY (
  set "LOCALPY="
  if exist "%~dp0python-path.txt" set /p LOCALPY=<"%~dp0python-path.txt"
  if defined LOCALPY if exist "!LOCALPY!" (
    set PLAINPY="!LOCALPY!"
    "!LOCALPY!" -c "import PIL" >nul 2>&1
    if not errorlevel 1 set PYEXE="!LOCALPY!"
  )
)

rem --- 3) Windows py launcher ---
if not defined PLAINPY (
  py -3 -c "import sys" >nul 2>&1
  if not errorlevel 1 (
    set "PLAINPY=py -3"
    py -3 -c "import PIL" >nul 2>&1
    if not errorlevel 1 set "PYEXE=py -3"
  )
)

rem --- 4) python on PATH ---
if not defined PLAINPY (
  python -c "import sys" >nul 2>&1
  if not errorlevel 1 (
    set "PLAINPY=python"
    python -c "import PIL" >nul 2>&1
    if not errorlevel 1 set "PYEXE=python"
  )
)

rem --- 5) per-user Python installs ---
if not defined PLAINPY (
  for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python31*") do (
    if not defined PLAINPY if exist "%%~fD\python.exe" (
      set "PLAINPY="%%~fD\python.exe""
      "%%~fD\python.exe" -c "import PIL" >nul 2>&1
      if not errorlevel 1 set "PYEXE="%%~fD\python.exe""
    )
  )
)

if defined PYEXE goto found
if defined PLAINPY goto needpillow
goto nopython

rem ================================================================
:needpillow
echo       Python found : %PLAINPY%
echo       Pillow       : MISSING
echo.
echo       Pillow is required - it reads the image and writes the result.
echo       Install it now? It downloads about 3 MB from the internet.
echo.
set "ANSWER="
set /p ANSWER=      Type Y to install, or just press Enter to cancel:
if /i not "%ANSWER%"=="Y" goto pillowhelp
echo.
echo       Installing Pillow, please wait ...
%PLAINPY% -m pip install --user Pillow
%PLAINPY% -c "import PIL" >nul 2>&1
if errorlevel 1 goto pillowfail
set "PYEXE=%PLAINPY%"
echo.
echo       OK   Pillow installed.
goto found

rem ================================================================
:found
echo       OK   %PYEXE%
echo.
echo [2/3] Starting the service in the background ...
set "CAPTION_PY=%PYEXE%"
set "CAPTION_PORT=%PORT%"
cscript //nologo "%~dp0_run_hidden.vbs" >nul 2>&1
echo [3/3] Waiting for the service to come up ...
ping -n 4 127.0.0.1 >nul

netstat -ano | findstr /r /c:":%PORT% .*LISTENING" >nul 2>&1
if errorlevel 1 goto failed

echo.
echo       OK. Your browser is opening now.
echo.
echo       URL   : http://127.0.0.1:%PORT%/
echo       Stop  : double-click the other .bat file in this folder
echo       Log   : serve.log in this folder
echo.
echo       This window closes by itself now.
ping -n 3 127.0.0.1 >nul
exit /b 0

rem ================================================================
:failed
echo.
echo [ERROR] The service did not start.
echo         Last lines of serve.log:
echo ----------------------------------------------------------------
powershell -NoProfile -Command "if(Test-Path 'serve.log'){Get-Content 'serve.log' -Tail 15} else {'(no log file)'}"
echo ----------------------------------------------------------------
echo.
echo   Tip: if the port is busy, run this file with a port number
echo        appended, for example:   %~nx0 8802
echo.
pause
exit /b 1

rem ================================================================
:pillowhelp
echo.
echo       Cancelled. To install it yourself, open a command prompt
echo       and run this line:
echo.
echo           %PLAINPY% -m pip install --user Pillow
echo.
pause
exit /b 1

:pillowfail
echo.
echo [ERROR] Installing Pillow failed.
echo         Check the internet connection, or run this line manually:
echo.
echo           %PLAINPY% -m pip install --user Pillow
echo.
pause
exit /b 1

rem ================================================================
:nopython
echo.
echo [ERROR] No Python 3 was found on this computer.
echo.
echo   1. Install Python 3 from https://www.python.org/downloads/
echo      (tick "Add python.exe to PATH" during setup)
echo   2. Run this file again - it will offer to install Pillow.
echo.
echo   Advanced options:
echo     - drop a portable Python at  %~dp0python\python.exe
echo     - or create a file named  python-path.txt  next to this one,
echo       containing one line: the full path of a python.exe that
echo       already has Pillow installed
echo.
pause
exit /b 1

@echo off
setlocal
set "PORT=%~1"
if "%PORT%"=="" set "PORT=8801"

echo Stopping Magazine Caption Studio (port %PORT%) ...
echo.

curl -s -m 5 -X POST "http://127.0.0.1:%PORT%/api/shutdown" -H "Content-Type: application/json" -d "{}" >nul 2>&1
if errorlevel 1 (
  powershell -NoProfile -Command "try{Invoke-RestMethod -Method Post -Uri 'http://127.0.0.1:%PORT%/api/shutdown' -ContentType 'application/json' -Body '{}' | Out-Null; exit 0}catch{exit 1}" >nul 2>&1
)

ping -n 3 127.0.0.1 >nul
netstat -ano | findstr /r /c:":%PORT% .*LISTENING" >nul 2>&1
if errorlevel 1 (
  echo       Stopped. Temporary files have been cleaned.
) else (
  echo       Still listening on port %PORT%.
  echo       Please run this file again, or close it in Task Manager.
)
echo.
ping -n 4 127.0.0.1 >nul
exit /b 0

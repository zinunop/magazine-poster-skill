# -*- coding: utf-8 -*-
"""通用版：给图片加杂志封面式文字装饰（随机化 + 防重叠 + 标题样式预设）

用法:
  python caption.py <输入图>                      # 全自动，每次装饰都不同
  python caption.py <图> --seed 42                # 固定种子，可复现
  python caption.py <图> --density 1.6            # 装饰密度倍率（默认 1.0）
  python caption.py <图> --title ANON --item "TWEED SET"
  python caption.py <图> --colors "#1b3a5c,#efe7d8"
  python caption.py <图> --tag-meta                # 只给这张图补写标题元数据（不排版）
"""
import argparse, base64, json, os, random, re, statistics, struct, subprocess, tempfile, zlib
from html import escape
from pathlib import Path
from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageStat

EDGE = r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe'   # 兜底路径
HERE = os.path.dirname(os.path.abspath(__file__))

# 标题/正文衬线字体：georgia 数字是「旧式数字」（3/4/5/7/9 会下探到基线以下），
# 含数字的标题会显得没对齐；sourcehan（思源宋体/宋体）数字等高，可避免该问题。
SERIF_STACKS = {
    'georgia': "Georgia,'Times New Roman',serif",
    'sourcehan': ("'Source Han Serif SC','Noto Serif SC','Noto Serif CJK SC',"
                  "'思源宋体',SimSun,'Songti SC',serif"),
}

# build_page / render 允许的参数名（拼错参数名会被直接拒绝，避免静默失效）
PAGE_OPTIONS = {
    'title', 'name', 'item', 'item2', 'brand', 'kicker', 'issue', 'year', 'foot',
    'ink', 'colors', 'seed', 'density', 'n_line', 'n_shape', 'pad', 'edge',
    'row_boost', 'n_bands', 'lw', 'tsize', 'toff', 'toffx', 'zone',
    'font', 'dscale', 'dalpha', 'grid', 'safe', 'bg', 'gap', 'img_src', 'preset',
    'cutout', 'overrides',
}

# ---------- 预设（presets/*.json） ----------
PRESET_DIR = os.path.join(HERE, 'presets')
DEFAULT_PRESET = 'magazine-poster-01'

# 出图时写进 PNG 的元数据键（Magazine Poster 01 流程用）。
# 有它就优先用（不依赖提示词格式）；没有就回退到解析提示词 —— 老图照样能用。
META_KEY = 'MagazinePoster'

# 预设里没写的字段，用这里的值补齐
PRESET_FALLBACK = {
    'name': '未命名预设',
    'description': '',
    'texts': {
        'brand': 'MYGO!!!!!  /  BANG DREAM!',
        'kicker': 'FASHION EDITORIAL',
        'issue': 'ISSUE 01',
        'year': '2026',
        'foot': 'FASHION EDITORIAL  /  STUDIO SERIES  /  VOL. 01',
        'item2': 'EDITORIAL  /  STUDIO',
        'item_fallback': 'FASHION LOOK',
    },
    'palette': {'bg': '#e9dfcb', 'ink': '#16263f'},
    'title': {
        'font': 'georgia',
        'size': [0.066, 0.117, 0.735],       # 字号 = clamp(H*min, H*k/字数, H*max)
        'zones': ['left', 'left', 'right', 'bottom', 'leftbottom'],
        'styles': [],                         # 空 = 该区域的全部样式；否则只从列出的里挑
    },
    'decor': {
        'line': ['hatch', 'vline', 'hline', 'wave', 'curve', 'dash', 'arc2'],
        'shape': ['ring', 'starcircle', 'cross', 'square', 'dotgrid', 'triangle',
                  'frame', 'barcircle', 'arc', 'tri_solid', 'rect_solid', 'circle_solid'],
        'color': 'person',                    # person = 取人物配色（含墨色兜底）；ink = 只用墨色
        'defaults': {},
    },
    'chrome': {                               # 版面上的固定元件，可整套关掉
        'veil': True, 'bar': True, 'botbar': True, 'top': True, 'kicker': True,
        'swatches': True, 'info': True, 'issue': True, 'footline': True,
    },
}


# 元件表预设没写 ui 时，按元件类型自动分组（顺序即面板里的分组顺序）
UI_FALLBACK_GROUPS = (
    ('标题', ('title', 'bands')),
    ('文字', ('text',)),
    ('图形', ('rect', 'line', 'polygon')),
    ('效果', ('scrim', 'decor', 'repeat', 'svg')),
)


def default_ui(pre):
    """给「有 elements 但没写 ui」的预设生成一份默认面板声明。

    为什么必须有：前端只在预设声明了 ui 时才生成元件面板；否则退回老的静态面板，
    而静态参数（字号 / 装饰数量 / 配色…）对元件表路径**不生效** —— 用户改半天
    预览纹丝不动，看起来像"这个预设坏了"。所以这里兜底，保证有元件表就一定有面板。
    """
    groups, used = [], set()
    for label, types in UI_FALLBACK_GROUPS:
        ids = [el.get('id') for el in (pre.get('elements') or [])
               if el.get('type') in types and el.get('id')]
        if ids:
            groups.append({'label': label, 'elements': ids})
            used.update(ids)
    rest = [el.get('id') for el in (pre.get('elements') or [])
            if el.get('id') and el.get('id') not in used and el.get('type') != 'image']
    if rest:                                  # image 元件没有可调项，不进面板
        groups.append({'label': '其他', 'elements': rest})
    if pre.get('switches'):
        groups.append({'label': '开关', 'switches': list(pre['switches'])})
    groups.append({'label': '取色', 'fields': ['color_shift']})
    groups.append({'label': '随机', 'fields': ['random_switch']})
    return {'groups': groups}


def _deep_merge(base, extra):
    """把 extra 合并进 base 的副本（嵌套 dict 逐层合并）。"""
    out = json.loads(json.dumps(base))
    for key, value in (extra or {}).items():
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            out[key].update(value)
        else:
            out[key] = value
    return out


def list_presets():
    """列出 presets/ 下的全部预设；一个都没有时回退到内置默认。"""
    out = []
    if os.path.isdir(PRESET_DIR):
        for name in sorted(os.listdir(PRESET_DIR)):
            if not name.endswith('.json'):
                continue
            pid = name[:-5]
            try:
                with open(os.path.join(PRESET_DIR, name), encoding='utf-8') as f:
                    data = json.load(f)
            except Exception:
                continue
            if isinstance(data, dict):
                out.append({'id': pid, 'name': data.get('name') or pid,
                            'description': data.get('description') or ''})
    if not out:
        out.append({'id': DEFAULT_PRESET, 'name': '内置默认', 'description': ''})
    return out


def load_preset(name):
    """读取预设并补齐缺省字段。名称非法或文件不存在 → 回退内置默认。"""
    data = None
    if name and re.fullmatch(r'[A-Za-z0-9_\-]{1,40}', str(name)):
        path = os.path.join(PRESET_DIR, str(name) + '.json')
        if os.path.isfile(path):
            try:
                with open(path, encoding='utf-8') as f:
                    loaded = json.load(f)
                if isinstance(loaded, dict):
                    data = loaded
            except Exception as exc:
                print('[CaptionStudio] 预设 %s 读取失败：%s' % (name, exc))
    merged = _deep_merge(PRESET_FALLBACK, data)
    merged['id'] = str(name) if data else DEFAULT_PRESET
    if merged.get('elements') and not merged.get('ui'):
        merged['ui'] = default_ui(merged)     # 元件表预设兜底一份面板声明
    return merged


def preset_ui_defaults(pre):
    """把预设里能直接映射到界面的默认值拍平，供前端切换预设时套用。"""
    d = pre['decor'].get('defaults') or {}
    out = {
        'texts': {key: pre['texts'].get(key, '') for key in
                  ('brand', 'kicker', 'issue', 'year', 'foot', 'item2')},
        'font': pre['title']['font'],
        'bg': pre['palette']['bg'],
        'ink': pre['palette']['ink'],
    }
    if 'density' in d:
        out['density'] = d['density']
    if 'lw' in d:
        out['lw'] = d['lw']
    for key, ctrl in (('n_line', 'nline'), ('n_shape', 'nshape')):
        pair = d.get(key)
        if isinstance(pair, (list, tuple)) and len(pair) == 2:
            out[ctrl], out[ctrl + '2'] = pair[0], pair[1]
    return out


def find_browser():
    """定位可用的 Chromium 内核浏览器（Edge / Chrome）用于无头截图。

    顺序：环境变量 CAPTION_BROWSER → 常见安装目录 → 注册表 → 兜底常量。
    换机器或换安装位置时不必改代码。
    """
    env = os.environ.get('CAPTION_BROWSER')
    if env and os.path.isfile(env):
        return env
    roots = [os.environ.get('PROGRAMFILES(X86)'), os.environ.get('PROGRAMFILES'),
             os.environ.get('LOCALAPPDATA')]
    rel = (r'Microsoft\Edge\Application\msedge.exe', r'Google\Chrome\Application\chrome.exe')
    for root in roots:
        if not root:
            continue
        for name in rel:
            path = os.path.join(root, name)
            if os.path.isfile(path):
                return path
    try:                                     # 注册表兜底（覆盖自定义安装位置）
        import winreg
        for exe in ('msedge.exe', 'chrome.exe'):
            for hive in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
                try:
                    key = r'SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\%s' % exe
                    with winreg.OpenKey(hive, key) as handle:
                        path = winreg.QueryValueEx(handle, '')[0]
                    if path and os.path.isfile(path):
                        return path
                except OSError:
                    continue
    except ImportError:
        pass
    return EDGE


# ---------- 1) 元数据解析 ----------
def read_prompt(path):
    try:
        with Image.open(path) as im:
            raw = im.info.get('prompt')
        if not raw:
            return ''
        d = json.loads(raw)
        if '375' in d:
            return d['375']['inputs'].get('value', '')
    except Exception:
        pass
    return ''


def read_meta(path):
    """读出图流程写进 PNG 的元数据。

    这是「主路」：由出图脚本按角色库写入，不依赖提示词的写法，
    所以非 BanG Dream 角色、或 trigger 里带括号/逗号的角色也能准确读出标题。
    读不到（老图、手工图）就返回空 dict，调用方回退到解析提示词。
    """
    try:
        with Image.open(path) as im:
            raw = im.info.get(META_KEY)
        data = json.loads(raw) if raw else {}
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def write_png_text(path, key, value):
    """在 PNG 的 IHDR 之后插入（或替换同名）一个 iTXt 文本块。

    只动元数据，像素与已有的 prompt 块原封不动 —— 所以对图片本身零影响。
    """
    key_b, text_b = key.encode('latin-1'), value.encode('utf-8')
    payload = key_b + b'\x00' * 5 + text_b
    chunk = (struct.pack('>I', len(payload)) + b'iTXt' + payload +
             struct.pack('>I', zlib.crc32(b'iTXt' + payload) & 0xffffffff))
    data = open(path, 'rb').read()
    ln = struct.unpack('>I', data[8:12])[0]
    out = bytearray(data[:20 + ln])
    out += chunk
    i = 20 + ln
    while i < len(data):
        ln = struct.unpack('>I', data[i:i + 4])[0]
        typ, blk = data[i + 4:i + 8], data[i:i + 12 + ln]
        i += 12 + ln
        if typ in (b'iTXt', b'tEXt', b'zTXt') and blk[8:8 + ln].split(b'\x00', 1)[0] == key_b:
            continue
        out += blk
    with open(path, 'wb') as f:
        f.write(bytes(out))


def tag_meta_from_prompt(path, title=None, name=None):
    """给**已有**图片补写元数据：标题/角色名从图里已嵌入的提示词解析出来。

    出图流程会自动写元数据；这个函数是给老图补标记用的（不用重新出图）。
    `title` / `name` 传了就用传的，否则从提示词解析。
    """
    if title is None or name is None:
        prompt = read_prompt(path)
        if not prompt and title is None:
            raise ValueError('这张图里没有嵌入提示词，无法自动补写（可用 --title / --name 手工指定）')
        auto_title = guess_title(prompt) if prompt else ''
        auto_name = (guess_name(prompt) or auto_title) if prompt else ''
        title = title or auto_title
        name = name or auto_name or title
    meta = {'title': title, 'name': name, 'source': 'prompt'}
    write_png_text(path, META_KEY, json.dumps(meta, ensure_ascii=False))
    return meta


def guess_title(prompt):
    if not prompt:
        return 'UNTITLED'
    m = re.search(r'\n?1girl,\s*([a-z0-9\' ]+?),\s*bang dream!', prompt, re.I)
    if m:
        return m.group(1).strip().split()[-1].upper()
    m = re.search(r'1girl,\s*([a-z0-9\' ]{3,40}?),\s*[a-z0-9]', prompt, re.I)
    if m:
        return m.group(1).strip().split()[-1].upper()
    return 'UNTITLED'


def guess_name(prompt):
    if not prompt:
        return ''
    m = re.search(r'1girl,\s*([a-z0-9\' ]+?),\s*bang dream!', prompt, re.I)
    return m.group(1).strip().upper() if m else ''


def guess_item(prompt):
    if not prompt:
        return None
    m = re.search(r'wearing\s+([^,]+)', prompt, re.I)
    if not m:
        return None
    words = m.group(1).strip().upper().split()
    while words and words[0] in ('A', 'AN', 'THE', 'AND', 'OVER', 'WITH'):
        words.pop(0)
    out = []
    for w in words:
        if w in ('AND', 'OVER', 'WITH', 'UNDER', 'ON'):
            break
        out.append(w)
        if len(' '.join(out)) > 30:
            break
    return ' '.join(out)[:32] if out else None


# ---------- 2) 配色提取 ----------
def extract_colors(path, n=4):
    try:
        im = Image.open(path).convert('RGB')
        w, h = im.size
        corners = [im.getpixel(p) for p in ((3, 3), (w - 4, 3), (3, h - 4), (w - 4, h - 4))]
        bg = tuple(sum(c[i] for c in corners) // 4 for i in range(3))
        crop = im.crop((int(w * 0.18), int(h * 0.18), int(w * 0.82), int(h * 0.86)))
        crop = crop.resize((96, 96))
        q = crop.quantize(colors=n + 3, method=Image.MEDIANCUT).convert('RGB')
        counts = sorted(q.getcolors(96 * 96) or [], reverse=True)
        total = 96 * 96
        out = []
        for cnt, rgb in counts:
            if cnt / total > 0.34:
                continue
            if sum((rgb[i] - bg[i]) ** 2 for i in range(3)) ** 0.5 < 42:
                continue
            lum = 0.299 * rgb[0] + 0.587 * rgb[1] + 0.114 * rgb[2]
            if 25 < lum < 232:
                out.append('#%02x%02x%02x' % rgb)
        while len(out) < n:
            out.append('#8fa8c4')
        return out[:n]
    except Exception:
        return ['#1b3a5c', '#efe7d8', '#b0392c', '#8fa8c4']


def mix_hex(c1, c2):
    """两个十六进制颜色取平均"""
    a = tuple(int(c1[i:i + 2], 16) for i in (1, 3, 5))
    b = tuple(int(c2[i:i + 2], 16) for i in (1, 3, 5))
    return '#%02x%02x%02x' % tuple((a[i] + b[i]) // 2 for i in range(3))


def person_bbox(path, scale=64):
    """纯算法找人物主体：颜色差异 + 连通域 → 归一化包围盒 (x0,y0,x1,y1)。
    思路：与「四角背景色」差异大的像素视为前景，取最大连通块，求外接框。"""
    try:
        im = Image.open(path).convert('RGB')
        W, H = im.size
        sw = scale
        sh = max(8, int(scale * H / W))
        small = im.resize((sw, sh))
        px = small.load()
        corners = [px[1, 1], px[sw - 2, 1], px[1, sh - 2], px[sw - 2, sh - 2]]
        bg = tuple(sum(c[i] for c in corners) // 4 for i in range(3))

        fg = [[False] * sw for _ in range(sh)]
        for y in range(sh):
            for x in range(sw):
                r, g, b = px[x, y]
                d = ((r - bg[0]) ** 2 + (g - bg[1]) ** 2 + (b - bg[2]) ** 2) ** 0.5
                lum = 0.299 * r + 0.587 * g + 0.114 * b
                fg[y][x] = (d > 52) or (lum < 58)     # 与背景差异大，或很暗（深色衣/线稿）

        # 清掉边带：左右各 6%、底部 12%
        # —— 地面阴影/角落杂物常在此处，一旦与人物连通就会把外接框拉向画面边缘
        mx_ = int(sw * 0.06)
        my_ = int(sh * 0.88)
        for y in range(sh):
            for x in range(sw):
                if x < mx_ or x >= sw - mx_ or y >= my_:
                    fg[y][x] = False

        # 连通域 BFS：收集全部连通块
        seen = [[False] * sw for _ in range(sh)]
        comps = []
        for sy in range(sh):
            for sx in range(sw):
                if not fg[sy][sx] or seen[sy][sx]:
                    continue
                stack = [(sx, sy)]
                seen[sy][sx] = True
                cells = []
                while stack:
                    x, y = stack.pop()
                    cells.append((x, y))
                    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        nx, ny = x + dx, y + dy
                        if 0 <= nx < sw and 0 <= ny < sh and fg[ny][nx] and not seen[ny][nx]:
                            seen[ny][nx] = True
                            stack.append((nx, ny))
                comps.append(cells)

        # 选「面积大 且 重心靠近画面中轴」的块
        # —— 避免左下/右下的阴影杂物与人物连通后，把外接框拉到画面边缘
        best, best_score = None, -1.0
        for comp in comps:
            if len(comp) < sw * sh * 0.02:
                continue
            mx = sum(c[0] for c in comp) / len(comp)
            centrality = 1.0 - abs(mx - sw / 2.0) / (sw / 2.0)
            score = len(comp) * max(0.0, centrality)
            if score > best_score:
                best_score, best = score, comp

        if not best or len(best) < sw * sh * 0.02:
            return (0.20, 0.05, 0.80, 0.72)          # 回退：居中默认框

        xs = [c[0] for c in best]
        ys = [c[1] for c in best]
        return (min(xs) / sw, min(ys) / sh, (max(xs) + 1) / sw, (max(ys) + 1) / sh)
    except Exception:
        return (0.20, 0.05, 0.80, 0.72)


def person_mask(path, work=360, thresh=26, dark=58, feather=1.4):
    """逐像素抠出人物，返回全尺寸 alpha 蒙版（PIL 'L'，255 = 人物）。

    **只用 Pillow，不依赖 numpy。**

    步骤：四边像素的中位数当背景色 → 与背景差异大的像素算前景 → 从边界泛洪标出「外部背景」
    → 剩下没被标到的背景像素就是人物**内部孔洞**（米色裙子、两腿之间），一并填上
    → 边缘羽化，避免锯齿。

    ⚠️ `thresh` 默认 26 不是拍脑袋：PIL 的 `convert('L')` 算的是**加权亮度差**
    （绿权重 0.587 最高），而原来的 numpy 版用的是**欧氏距离**，量纲约为前者的 1.73 倍。
    阈值扫描后 26 正好复现 numpy 版的覆盖率（LD_00029 30.2% / LD_00037 26.8%）。

    ⚠️ 掩膜必须**先向外扩 1px 纯背景边**再泛洪：否则当四边被误判成前景时，
       泛洪拿不到种子，整张图会被当成「内部孔洞」填满 —— 实测踩过这个坑。
    """
    im = Image.open(path).convert('RGB')
    W, H = im.size
    sh = max(8, int(work * H / W))
    small = im.resize((work, sh), Image.LANCZOS)

    edge = (list(small.crop((0, 0, work, 1)).getdata())
            + list(small.crop((0, sh - 1, work, sh)).getdata())
            + list(small.crop((0, 0, 1, sh)).getdata())
            + list(small.crop((work - 1, 0, work, sh)).getdata()))
    bg = tuple(int(statistics.median(c[i] for c in edge)) for i in range(3))

    # 与背景差异大 → 前景；很暗（深色衣 / 线稿）→ 也算前景
    diff = ImageChops.difference(small, Image.new('RGB', small.size, bg)).convert('L')
    fg = ImageChops.lighter(diff.point(lambda v: 255 if v > thresh else 0),
                            small.convert('L').point(lambda v: 255 if v < dark else 0))

    # 外扩 1px 背景边 → 泛洪把「外部背景」染成 128；剩下还是 0 的即内部孔洞
    pad = Image.new('L', (work + 2, sh + 2), 0)
    pad.paste(fg, (1, 1))
    ImageDraw.floodfill(pad, (0, 0), 128, thresh=0)
    holes = pad.crop((1, 1, work + 1, sh + 1)).point(lambda v: 255 if v == 0 else 0)

    filled = ImageChops.lighter(fg, holes)
    return filled.filter(ImageFilter.GaussianBlur(feather)).resize((W, H), Image.LANCZOS)


_MASK_CACHE = {}


def mask_data_uri(path, work=360, **kw):
    """把人物蒙版编成 data URI，给 CSS 的 mask-image 用。

    刻意存成 **RGBA（白色 + alpha）**而不是灰度：实测灰度 PNG 在无头 Edge 里
    `mask-image` 不生效（背景只透出 3.0%），换成 RGBA 后正常（70.8%）。
    比加 `mask-mode:luminance` 更稳 —— 那个属性兼容性更差。

    ⚠️ 带缓存：实时预览每改一个参数都会调这里，不缓存的话每次都重算蒙版（约 0.3 秒）。
    """
    from io import BytesIO
    try:
        key = (os.path.abspath(path), os.path.getmtime(path), work,
               tuple(sorted((k, str(v)) for k, v in kw.items())))
    except OSError:
        key = None
    if key is not None and key in _MASK_CACHE:
        return _MASK_CACHE[key]

    m = person_mask(path, work=work, **kw)
    rgba = Image.new('RGBA', m.size, (255, 255, 255, 0))
    rgba.putalpha(m)
    buf = BytesIO()
    rgba.save(buf, format='PNG', optimize=True)
    uri = 'data:image/png;base64,' + base64.b64encode(buf.getvalue()).decode()

    if key is not None:
        if len(_MASK_CACHE) >= 8:                    # 只留最近 8 张，别无限涨
            _MASK_CACHE.pop(next(iter(_MASK_CACHE)))
        _MASK_CACHE[key] = uri
    return uri


# ---------- 3) 随机装饰（统一池 + 防重叠） ----------
class Placer:
    """矩形占位管理：保证装饰之间不重叠（含最小间距），并支持避障区"""

    def __init__(self, W, H, pad=12, y_min=0, y_max=None, obstacles=None, edge_pad=40, rng=None):
        self.rng = rng if rng is not None else random.Random()
        self.W, self.H, self.pad = W, H, pad
        self.edge_pad = edge_pad
        self.y_min = y_min
        self.y_max = y_max if y_max is not None else H
        self.boxes = list(obstacles or [])

    def fits(self, x, y, w, h):
        p = self.pad
        for (bx, by, bw, bh) in self.boxes:
            if not (x + w + p <= bx or bx + bw + p <= x or
                    y + h + p <= by or by + bh + p <= y):
                return False
        return True

    def place(self, w, h, region=None, tries=80):
        """在指定区域（或整个安全区）内随机找不重叠位置；失败返回 None"""
        m = self.edge_pad                      # 边缘留白：装饰不贴边
        if region:
            x0, y0, x1, y1 = region
            x0, y0 = max(m, x0), max(self.y_min, y0)
            x1, y1 = min(self.W - m, x1), min(self.y_max, y1)
        else:
            x0, y0, x1, y1 = m, self.y_min, self.W - m, self.y_max
        if x1 - x0 < w + 4 or y1 - y0 < h + 4:
            return None
        for _ in range(tries):
            x = self.rng.randint(int(x0), int(x1 - w))
            y = self.rng.randint(int(y0), int(y1 - h))
            if self.fits(x, y, w, h):
                self.boxes.append((x, y, w, h))
                return x, y
        return None


UPPER_BODY = 0.55          # 装饰避障只覆盖人物的这一段高度（头肩胸），下半身留给装饰


def build_decor(rng, W, H, ink, cols, density=1.0, extra_obstacles=None, person_box=None,
                n_line=(4, 7), n_shape=(6, 10), pad=20, edge=None, row_boost=1.55,
                n_bands=(2, 4), lw=4, dscale=1.0, dalpha=1.0, grid=(4, 5),
                safe=0.16, gap=14, line_names=None, shape_names=None, decor_color='person'):
    """装饰（线条池 + 几何池）+ 防重叠 + 网格密度。返回 (css, html, bands)

    dscale 装饰整体尺寸倍率｜dalpha 透明度倍率｜grid 网格密度（列, 行）｜
    safe 上下安全区比例｜gap 装饰之间的最小间距（px）｜
    line_names / shape_names 由预设决定启用哪些形状｜decor_color 取色方式
    """
    # 每次渲染独立随机源，避免并发时互相改动全局随机状态。
    TOP_SAFE = int(H * safe)        # 顶部品牌/标题区留白（按高度比例，适配任意尺寸）
    BOT_SAFE = int(H * safe)        # 底部信息行/色块区留白

    # 避障区：优先用「颜色识别」得到的人物包围盒（再随机外扩 → 保留不规则感）
    obstacles = []
    if person_box:
        bx0, by0, bx1, by1 = person_box
        j = max(0, int(pad))
        # 只避「上半身」（头 / 肩 / 胸），下半身（裙摆、腿）留给装饰。
        # 为什么：人物占画面较满时（实测占宽 80%），按「整个人」避障会把可用区挤成
        # 左右两条窄缝 → 装饰数量从 10~17 骤减到 7，且几乎全堆在较宽的那一侧。
        # 改成只避上半身后：实测装饰数恢复到 17、左右分布 10/7。
        upper = by0 + (by1 - by0) * UPPER_BODY
        obstacles.append((
            int(bx0 * W) - rng.randint(0, max(0, int(j * 0.65))),
            int(by0 * H) - rng.randint(0, max(0, int(j * 0.5))),
            int((bx1 - bx0) * W) + rng.randint(0, max(0, int(j * 1.1))),
            int((upper - by0) * H) + rng.randint(0, max(0, int(j * 0.8))),
        ))
    else:
        # 回退：按比例的三矩形
        for (fx, fy, fw, fh, jx, jy) in (
                (0.14, 0.02, 0.72, 0.26, 36, 24),
                (0.20, 0.20, 0.62, 0.32, 34, 30),
                (0.16, 0.46, 0.66, 0.20, 32, 26)):
            obstacles.append((
                int(W * fx) + rng.randint(-jx, jx),
                int(H * fy) + rng.randint(-jy, jy),
                int(W * fw) + rng.randint(-28, 28),
                int(H * fh) + rng.randint(-28, 28),
            ))

    if extra_obstacles:
        obstacles.extend(extra_obstacles)      # 标题占位也计入避障
    EDGE = int(W * 0.055) if edge is None else max(0, int(edge))
    placer = Placer(W, H, pad=max(0, int(gap)), y_min=TOP_SAFE, y_max=H - BOT_SAFE,
                    obstacles=obstacles, edge_pad=EDGE, rng=rng)

    css, html = [], []
    k = [0]

    def reg(style, inner='', scale=1.0):
        k[0] += 1
        cls = 'd%d' % k[0]
        extra = ''
        if abs(scale - 1.0) > 1e-6:                      # 整体尺寸倍率（占位框同步缩放）
            extra += ' transform:scale(%.4f); transform-origin:0 0;' % scale
        if abs(dalpha - 1.0) > 1e-6:                     # 透明度倍率：直接改 opacity 数值
            style = re.sub(r'opacity:([0-9.]+);',
                           lambda m: 'opacity:%.3f;' % min(1.0, max(0.0, float(m.group(1)) * dalpha)),
                           style)
        css.append('.%s { position:absolute; %s%s }' % (cls, style, extra))
        html.append('<div class="%s">%s</div>' % (cls, inner))

    # 网格密度控制：按「格子越空权重越大」加权选格 → 整体尽量均匀，但允许疏密
    GW, GH = max(2, int(grid[0])), max(2, int(grid[1]))
    grid = [[0] * GW for _ in range(GH)]
    Y_MIN, Y_MAX = TOP_SAFE, H - BOT_SAFE
    cw, chh = (W - 2 * EDGE) / GW, (Y_MAX - Y_MIN) / GH

    def cell_free(gx, gy):
        """该格「未被避障区占用」的比例（0~1）"""
        x0, y0 = EDGE + gx * cw, Y_MIN + gy * chh
        x1, y1 = x0 + cw, y0 + chh
        # 合并交叠矩形后求面积，人物框与加厚框不能重复计数。
        rects = [(max(x0, bx), max(y0, by), min(x1, bx + bw), min(y1, by + bh))
                 for bx, by, bw, bh in placer.boxes]
        rects = [r for r in rects if r[2] > r[0] and r[3] > r[1]]
        cuts = sorted({v for r in rects for v in (r[0], r[2])})
        blocked = 0.0
        for left, right in zip(cuts, cuts[1:]):
            intervals = sorted((r[1], r[3]) for r in rects if r[0] < right and r[2] > left)
            end, height = y0, 0.0
            for start, stop in intervals:
                height += max(0.0, stop - max(start, end))
                end = max(end, stop)
            blocked += (right - left) * height
        return max(0.0, 1.0 - blocked / max(1.0, cw * chh))

    def pick_cell():
        # 权重 = 行权重（上密下疏）× 格子空闲率（避开人物/标题）× 越空越大
        weights = []
        for gy in range(GH):
            rb = 0.55 + (GH - 1 - gy) / max(1, GH - 1) * row_boost
            for gx in range(GW):
                free = cell_free(gx, gy)
                weights.append(0.0 if free < 0.18 else rb * free / (1.0 + grid[gy][gx]))
        total = sum(weights)
        if total <= 0:
            return None
        r = rng.uniform(0, total)
        acc = 0.0
        for idx, wgt in enumerate(weights):
            acc += wgt
            if r <= acc:
                return idx % GW, idx // GW
        return GW - 1, GH - 1

    def put(style_fn, w, h, inner=''):
        """先按网格选区域、再算不重叠位置；自动避开避障区与已有装饰。

        占位框按 dscale 缩放，与 CSS transform 的视觉尺寸保持一致。
        """
        bw = max(1, int(round(w * dscale)))
        bh = max(1, int(round(h * dscale)))
        pos = None
        for _ in range(12):
            cell = pick_cell()
            if cell is None:
                return False
            gx, gy = cell
            # 允许长线跨格，但不回退到无权重的全局随机放置。
            region = (int(EDGE + gx * cw - bw / 2), int(Y_MIN + gy * chh - bh / 2),
                      int(EDGE + (gx + 1) * cw + bw / 2), int(Y_MIN + (gy + 1) * chh + bh / 2))
            pos = placer.place(bw, bh, region=region)
            if pos:
                break
        if not pos:
            return False
        x, y = pos
        actual_gx = min(GW - 1, max(0, int((x + bw / 2 - EDGE) / max(1, cw))))
        actual_gy = min(GH - 1, max(0, int((y + bh / 2 - Y_MIN) / max(1, chh))))
        grid[actual_gy][actual_gx] += 1
        reg(style_fn(x, y), inner, dscale)
        return True

    # ---- 装饰配色：person = 取人物身上的颜色（少量墨色兜底）；ink = 只用墨色 ----
    def dcol():
        if decor_color == 'ink':
            return ink
        return rng.choice(list(cols) + [ink])

    # ---- 装饰生成器（线条池 / 几何池） ----
    def g_hatch():
        w, h = rng.randint(60, 170), rng.randint(40, 170)
        op = round(rng.uniform(.2, .48), 2)
        return put(lambda x, y: 'left:%dpx; top:%dpx; width:%dpx; height:%dpx; opacity:%s;'
                                'background-image:repeating-linear-gradient(45deg, %s 0 4px, transparent 4px 15px);'
                   % (x, y, w, h, op, dcol()), w, h)

    def g_ring():
        d = rng.randint(44, 130)
        op = round(rng.uniform(.3, .6), 2)
        bw = rng.choice([lw, lw + 1, lw + 2])
        return put(lambda x, y: 'left:%dpx; top:%dpx; width:%dpx; height:%dpx; border:%dpx solid %s;'
                                'border-radius:50%%; opacity:%s;' % (x, y, d, d, bw, dcol(), op), d, d)

    def g_starcircle():
        d = rng.randint(84, 140)
        op = round(rng.uniform(.4, .7), 2)
        return put(lambda x, y: 'left:%dpx; top:%dpx; width:%dpx; height:%dpx; border:5px solid %s;'
                                'border-radius:50%%; opacity:%s; display:flex; align-items:center;'
                                'justify-content:center; font-size:%dpx; color:%s;'
                   % (x, y, d, d, dcol(), op, int(d * .3), dcol()), d, d, '&#9733;')

    def g_cross():
        fs = rng.randint(30, 58)
        op = round(rng.uniform(.4, .72), 2)
        return put(lambda x, y: 'left:%dpx; top:%dpx; font-size:%dpx; color:%s; opacity:%s;'
                   % (x, y, fs, dcol(), op), fs, fs, '+')

    def g_square():
        d = rng.randint(16, 46)
        op = round(rng.uniform(.35, .85), 2)
        return put(lambda x, y: 'left:%dpx; top:%dpx; width:%dpx; height:%dpx; background:%s; opacity:%s;'
                   % (x, y, d, d, dcol(), op), d, d)

    def g_vline():
        h = rng.randint(120, 460)
        w = rng.choice([lw, lw + 1, lw + 2])
        op = round(rng.uniform(.2, .46), 2)
        return put(lambda x, y: 'left:%dpx; top:%dpx; width:%dpx; height:%dpx; background:%s; opacity:%s;'
                   % (x, y, w, h, dcol(), op), w, h)

    def g_hline():
        w = rng.randint(80, 300)
        h = rng.choice([max(1, lw - 1), lw])
        op = round(rng.uniform(.25, .52), 2)
        return put(lambda x, y: 'left:%dpx; top:%dpx; width:%dpx; height:%dpx; background:%s; opacity:%s;'
                   % (x, y, w, h, dcol(), op), w, h)

    def g_dotgrid():
        d = rng.randint(36, 100)
        op = round(rng.uniform(.4, .72), 2)
        return put(lambda x, y: 'left:%dpx; top:%dpx; width:%dpx; height:%dpx; opacity:%s;'
                                'background-image:radial-gradient(%s 3.2px, transparent 3.4px);'
                                'background-size:13px 13px;' % (x, y, d, d, op, dcol()), d, d)

    def g_triangle():
        d = rng.randint(26, 62)
        op = round(rng.uniform(.35, .72), 2)
        return put(lambda x, y: 'left:%dpx; top:%dpx; width:0; height:0; opacity:%s;'
                                'border-left:%dpx solid transparent; border-right:%dpx solid transparent;'
                                'border-bottom:%dpx solid %s;' % (x, y, op, d, d, d, dcol()), d * 2, d)

    def g_frame():
        w, h = rng.randint(70, 160), rng.randint(50, 120)
        op = round(rng.uniform(.25, .52), 2)
        return put(lambda x, y: 'left:%dpx; top:%dpx; width:%dpx; height:%dpx; border:4px solid %s; opacity:%s;'
                   % (x, y, w, h, dcol(), op), w, h)

    def g_barcircle():          # 实心小圆点
        d = rng.randint(18, 40)
        op = round(rng.uniform(.35, .8), 2)
        c = rng.choice([ink] + list(cols))
        return put(lambda x, y: 'left:%dpx; top:%dpx; width:%dpx; height:%dpx; background:%s;'
                                'border-radius:50%%; opacity:%s;' % (x, y, d, d, c, op), d, d)

    def g_arc():                # 半圆弧
        d = rng.randint(60, 130)
        op = round(rng.uniform(.3, .55), 2)
        return put(lambda x, y: 'left:%dpx; top:%dpx; width:%dpx; height:%dpx;'
                                'border:5px solid %s; border-radius:50%%; opacity:%s;'
                                'clip-path:inset(0 0 50%% 0);' % (x, y, d, d, dcol(), op), d, d // 2)

    def g_wave():               # 波浪线（SVG）
        w, h = rng.randint(130, 300), rng.randint(40, 96)
        op = round(rng.uniform(.3, .6), 2)
        sw = rng.choice([lw, lw + 1, lw + 2])
        n = rng.randint(2, 4)
        step = w // n
        d = 'M0,%d' % (h // 2)
        for _ in range(n):
            d += ' q%d,%d %d,0' % (step // 2, -h // 2, step)
        svg = ('<svg width="%d" height="%d" viewBox="0 0 %d %d">'
               '<path d="%s" stroke="%s" stroke-width="%d" fill="none"/></svg>'
               % (w, h, w, h, d, dcol(), sw))
        return put(lambda x, y: 'left:%dpx; top:%dpx; opacity:%s;' % (x, y, op), w, h, svg)

    def g_curve():              # 单条大曲线（弧 / S 形）
        w, h = rng.randint(120, 260), rng.randint(60, 150)
        op = round(rng.uniform(.28, .58), 2)
        sw = rng.choice([lw, lw + 1, lw + 2])
        d = rng.choice(['M0,%d Q%d,0 %d,%d' % (h, w // 2, w, h),
                        'M0,0 Q%d,%d %d,%d' % (w // 2, h, w, 0),
                        'M0,%d C%d,0 %d,%d %d,%d' % (h, w // 3, 2 * w // 3, h, w, h // 2)])
        svg = ('<svg width="%d" height="%d" viewBox="0 0 %d %d">'
               '<path d="%s" stroke="%s" stroke-width="%d" fill="none"/></svg>'
               % (w, h, w, h, d, dcol(), sw))
        return put(lambda x, y: 'left:%dpx; top:%dpx; opacity:%s;' % (x, y, op), w, h, svg)

    def g_dash():               # 虚线
        w = rng.randint(90, 260)
        op = round(rng.uniform(.3, .6), 2)
        sw = rng.choice([max(1, lw - 1), lw])
        svg = ('<svg width="%d" height="8" viewBox="0 0 %d 8">'
               '<line x1="0" y1="4" x2="%d" y2="4" stroke="%s" stroke-width="%d"'
               ' stroke-dasharray="12 9" fill="none"/></svg>' % (w, w, w, dcol(), sw))
        return put(lambda x, y: 'left:%dpx; top:%dpx; opacity:%s;' % (x, y, op), w, 8, svg)

    def g_arc2():               # 四分之一圆弧（细线）
        d = rng.randint(60, 140)
        op = round(rng.uniform(.3, .6), 2)
        rot = rng.choice([0, 90, 180, 270])
        return put(lambda x, y: 'left:%dpx; top:%dpx; width:%dpx; height:%dpx;'
                                'border:5px solid %s; border-radius:50%%; opacity:%s;'
                                'clip-path:inset(0 50%% 50%% 0); transform:rotate(%ddeg);'
                   % (x, y, d, d, dcol(), op, rot), d, d)

    def g_tri_solid():          # 实心三角
        d = rng.randint(28, 64)
        op = round(rng.uniform(.35, .8), 2)
        return put(lambda x, y: 'left:%dpx; top:%dpx; width:0; height:0; opacity:%s;'
                                'border-left:%dpx solid transparent; border-right:%dpx solid transparent;'
                                'border-bottom:%dpx solid %s;' % (x, y, op, d, d, d, dcol()), d * 2, d)

    def g_rect_solid():         # 实心矩形（宽扁）
        w, h = rng.randint(40, 150), rng.randint(14, 60)
        op = round(rng.uniform(.35, .82), 2)
        return put(lambda x, y: 'left:%dpx; top:%dpx; width:%dpx; height:%dpx; background:%s; opacity:%s;'
                   % (x, y, w, h, dcol(), op), w, h)

    def g_circle_solid():       # 实心大圆
        d = rng.randint(26, 90)
        op = round(rng.uniform(.3, .75), 2)
        return put(lambda x, y: 'left:%dpx; top:%dpx; width:%dpx; height:%dpx; background:%s;'
                                'border-radius:50%%; opacity:%s;' % (x, y, d, d, dcol(), op), d, d)

    # 两个池子：线条型 / 几何型（几何含多种**实心**版本）
    # 具体启用哪些由预设的 decor.line / decor.shape 决定；列空或全不认则用默认全集
    gen = {'hatch': g_hatch, 'vline': g_vline, 'hline': g_hline, 'wave': g_wave,
           'curve': g_curve, 'dash': g_dash, 'arc2': g_arc2,
           'ring': g_ring, 'starcircle': g_starcircle, 'cross': g_cross, 'square': g_square,
           'dotgrid': g_dotgrid, 'triangle': g_triangle, 'frame': g_frame,
           'barcircle': g_barcircle, 'arc': g_arc, 'tri_solid': g_tri_solid,
           'rect_solid': g_rect_solid, 'circle_solid': g_circle_solid}
    line_pool = [gen[n] for n in (line_names or []) if n in gen] or \
                [g_hatch, g_vline, g_hline, g_wave, g_curve, g_dash, g_arc2]
    shape_pool = [gen[n] for n in (shape_names or []) if n in gen] or \
                 [g_ring, g_starcircle, g_cross, g_square, g_dotgrid, g_triangle,
                  g_frame, g_barcircle, g_arc, g_tri_solid, g_rect_solid, g_circle_solid]

    nL = max(0, int(rng.randint(int(n_line[0]), max(int(n_line[0]), int(n_line[1]))) * density))
    nS = max(0, int(rng.randint(int(n_shape[0]), max(int(n_shape[0]), int(n_shape[1]))) * density))

    for pool, cnt in ((line_pool, nL), (shape_pool, nS)):
        ok, tries = 0, 0
        while ok < cnt and tries < cnt * 8:
            tries += 1
            if rng.choice(pool)():
                ok += 1

    # ---- 背景斜线条（宽度/位置/角度/数量随机） ----
    bands = []
    nb0, nb1 = int(n_bands[0]), max(int(n_bands[0]), int(n_bands[1]))
    for _ in range(rng.randint(nb0, nb1)):
        top = rng.randint(int(H * .28), int(H * .88))
        hgt = rng.randint(14, 170)
        ang = rng.choice([-20, -16, -12, -8, 12, 16, 20])
        op = round(rng.uniform(.08, .30), 2)
        bands.append((top, hgt, ang, op))

    return '\n'.join(css), '\n'.join(html), bands


# ---------- 4) 标题样式预设 ----------
def build_title(rng, W, H, title, ink, cols, tsize=None, toff=0, toffx=0, zone=None,
                zones=None, styles=None, size_ratios=None):
    """标题只出现在【左 / 右 / 下 / 左下部】四个区域；样式与颜色随机。

    zones / styles / size_ratios 由预设提供：zones 是区域随机池（重复写=提高权重），
    styles 是样式白名单（留空=不限），size_ratios = (最小, 最大, 系数)。
    """
    if not title:
        return '', '', None
    lo, hi, kk = size_ratios or (0.066, 0.117, 0.735)
    size = tsize or max(int(H * lo), min(int(H * hi), int(H * kk / max(4, len(title)) * 0.92)))
    color = mix_hex(cols[0], cols[1])       # 标题用「最大两色的平均值」
    if not zone:
        zone = rng.choice(zones or ['left', 'left', 'right', 'bottom', 'leftbottom'])

    def pick(pool):
        """按预设的样式白名单过滤；过滤后为空则退回原池，避免出错。"""
        if styles:
            allowed = [s for s in pool if s in styles]
            if allowed:
                return rng.choice(allowed)
        return rng.choice(pool)
    ox = rng.randint(-12, 16) + int(toffx)   # 水平微偏移
    oy = rng.randint(-20, 20) - int(toff)    # 垂直微偏移（toff>0 表示上移）

    if zone == 'left':
        st = pick(['vserif', 'voutline', 'vcolor', 'vshadow', 'hserif', 'houtline', 'diag'])
        if st in ('hserif', 'houtline', 'diag'):
            if st == 'diag':
                fs = int(size * .62)
                ty = rng.randint(int(H * .52), int(H * .66)) + oy
                css = '.bigtitle{position:absolute; left:%dpx; top:%dpx; font-size:%dpx;' \
                      'line-height:1; font-weight:700; letter-spacing:8px; color:%s; opacity:.88;' \
                      'transform:rotate(-8deg); transform-origin:left center;}' % (56 + ox, ty, fs, color)
                box = (56 + ox, ty, int(fs * len(title) * .68), fs)
            else:
                fs = int(size * .78)
                ty = rng.randint(int(H * .55), int(H * .69)) + oy
                stroke = 'color:transparent; -webkit-text-stroke:3px %s;' % color if st == 'houtline' \
                         else 'color:%s;' % color
                css = '.bigtitle{position:absolute; left:%dpx; top:%dpx; font-size:%dpx;' \
                      'line-height:1; font-weight:700; letter-spacing:6px; %s opacity:.9;}' \
                      % (42 + ox, ty, fs, stroke)
                box = (42 + ox, ty, int(fs * len(title) * .68), fs)
        elif st == 'voutline':
            css = '.bigtitle{position:absolute; left:%dpx; top:%dpx; font-size:%dpx;' \
                  'line-height:.94; font-weight:700; writing-mode:vertical-rl;' \
                  'text-orientation:upright; color:transparent;' \
                  '-webkit-text-stroke:3px %s; opacity:.85;}' % (16 + ox, int(H * .098) + oy, size, color)
            box = (16 + ox, int(H * .098) + oy, size, int(size * len(title) * .94))
        elif st == 'vshadow':
            css = '.bigtitle{position:absolute; left:%dpx; top:%dpx; font-size:%dpx;' \
                  'line-height:.94; font-weight:700; writing-mode:vertical-rl;' \
                  'text-orientation:upright; color:%s; text-shadow:7px 7px 0 %s; opacity:.92;}' \
                  % (20 + ox, int(H * .105) + oy, size, color, rng.choice(cols))
            box = (20 + ox, int(H * .105) + oy, size + 12, int(size * len(title) * .94) + 12)
        else:   # vserif / vcolor
            css = '.bigtitle{position:absolute; left:%dpx; top:%dpx; font-size:%dpx;' \
                  'line-height:.94; font-weight:700; writing-mode:vertical-rl;' \
                  'text-orientation:upright; color:%s; opacity:.9;}' \
                  % (14 + ox, int(H * .100) + oy, size, color)
            box = (14 + ox, int(H * .100) + oy, size, int(size * len(title) * .94))

    elif zone == 'right':
        st = pick(['vserif', 'voutline', 'vcolor'])
        if st == 'voutline':
            css = '.bigtitle{position:absolute; right:%dpx; top:%dpx; font-size:%dpx;' \
                  'line-height:.94; font-weight:700; writing-mode:vertical-rl;' \
                  'text-orientation:upright; color:transparent;' \
                  '-webkit-text-stroke:3px %s; opacity:.85;}' % (28 - ox, int(H * .0875) + oy, size, color)
        else:
            css = '.bigtitle{position:absolute; right:%dpx; top:%dpx; font-size:%dpx;' \
                  'line-height:.94; font-weight:700; writing-mode:vertical-rl;' \
                  'text-orientation:upright; color:%s; opacity:.88;}' \
                  % (26 - ox, int(H * .0875) + oy, size, color)
        box = (W - 26 + ox - size, int(H * .0875) + oy, size, int(size * len(title) * .94))

    elif zone == 'leftbottom':      # 左下部横排 + 底色衬底（可压住人物）
        fs = int(size * .66)
        b = rng.randint(int(H * .164), int(H * .215)) - oy
        bgc = rng.choice(list(cols) + [ink])
        txc = '#f2ece0'  # 有色衬底样式保留浅色字，避免文字与底色同暗。
        css = '.bigtitle{position:absolute; left:%dpx; bottom:%dpx; font-size:%dpx;' \
              'line-height:1; font-weight:700; letter-spacing:8px; color:%s;' \
              'background:%s; padding:16px 30px 16px 44px; opacity:.96;}' \
              % (ox, b, fs, txc, bgc)
        box = (ox, H - b - fs - 32, int(fs * len(title) * .72) + 74, fs + 32)

    else:   # zone == 'bottom'
        st = pick(['hserif', 'houtline', 'hcolor'])
        fs = int(size * .72)
        b = rng.randint(int(H * .164), int(H * .211)) - oy
        stroke = 'color:transparent; -webkit-text-stroke:3px %s;' % color if st == 'houtline' \
                 else 'color:%s;' % color
        css = '.bigtitle{position:absolute; left:%dpx; bottom:%dpx; font-size:%dpx;' \
              'line-height:1; font-weight:700; letter-spacing:7px; %s opacity:.9;}' \
              % (42 + ox, b, fs, stroke)
        box = (42 + ox, H - b - fs, int(fs * len(title) * .66), fs)

    html = '<div class="bigtitle serif">%s</div>' % escape(title)
    return css, html, box


# ---------- 5) HTML 模板 ----------
TPL = """<!DOCTYPE html><html><head><meta charset="utf-8"><style>
* { margin:0; padding:0; box-sizing:border-box; }
html,body { width:__W__px; height:__H__px; overflow:hidden; background:__BG__; }
.canvas { position:relative; width:__W__px; height:__H__px; }
.art { position:absolute; left:0; top:0; width:__W__px; height:__H__px; }
__CUTOUT_CSS__
.ink { color:__INK__; }
.serif { font-family:__SERIF__; }
.sans { font-family:'Helvetica Neue',Arial,sans-serif; }

__BAND_CSS__
.veil-bottom { position:absolute; left:0; bottom:0; width:__W__px; height:22.7vh;
               background:linear-gradient(0deg, rgba(__VEIL_RGB__,.94), rgba(__VEIL_RGB__,0)); }
.bar { position:absolute; left:0; top:0; width:2.8vw; height:__H__px; background:__INK__; }
.botbar { position:absolute; left:0; bottom:3.0vh; width:__W__px; height:.23vh;
          background:__INK__; opacity:.28; }
.footline { position:absolute; left:0; bottom:1.1vh; width:__W__px; text-align:center;
            font-size:.86vh; letter-spacing:3.6px; opacity:.68; }

.top { position:absolute; left:5.8vw; top:3.0vh; }
.top .brand { font-size:1.02vh; letter-spacing:3.2px; font-weight:600; }
.top .rule { width:13.3vw; height:.16vh; background:__INK__; margin-top:.7vh; }
.kicker { position:absolute; left:5.8vw; top:7.7vh; font-size:.86vh;
          letter-spacing:4px; font-weight:600; opacity:.8; }

__TITLE_CSS__
__DECOR_CSS__

.swatch { position:absolute; }
.sw1 { right:1.9vw;  bottom:.8vh; width:5.8vh; height:5.8vh; background:__C1__; }
.sw2 { right:13.3vw; bottom:.8vh; width:3.8vh; height:3.8vh; background:__C2__;
       border:1px solid rgba(0,0,0,.15); }
.sw3 { right:1.9vw;  bottom:7.2vh; width:3.8vh; height:3.8vh; background:__C3__; }
.sw4 { right:13.3vw; bottom:5.2vh; width:2.2vh; height:2.2vh; background:__C4__; }

.info { position:absolute; left:7.2vw; bottom:8.1vh; }
.info .rule2 { width:16.7vw; height:1px; background:__INK__; opacity:.55; margin-bottom:.8vh; }
.info .item { font-size:1.33vh; letter-spacing:2.6px; font-weight:700; }
.info .item2 { font-size:.86vh; letter-spacing:2.4px; margin-top:.55vh; opacity:.72; }
.issue { position:absolute; right:6.1vw; bottom:16.4vh; text-align:right; }
.issue .no { font-size:2.03vh; letter-spacing:2px; font-weight:700; }
.issue .yr { font-size:.86vh; letter-spacing:4px; margin-top:.47vh; opacity:.72; }
</style></head><body><div class="canvas">
<img class="art" src="__IMG_SRC__">
__BAND_HTML__
__CHROME_VEIL____CHROME_BAR____CHROME_BOTBAR__
__CHROME_TOP__
__CHROME_KICKER__
__TITLE_HTML__
__DECOR_HTML__
__CHROME_SWATCHES__
__CHROME_INFO__
__CHROME_ISSUE__
__CHROME_FOOTLINE__
__CUTOUT_HTML__
</div></body></html>"""


def build_elements_page(src, pre, opts):
    """**元件表路径** —— 预设里写了 "elements" 时才走这里（老模板完全不参与）。

    与老路径共用同一套「取值优先级」和配色逻辑，但版式由元件表描述。
    """
    # elements.py 必须和 caption.py 在同一个文件夹。分开报错，免得"文件不在"和
    # "它自己依赖缺失"混成一句话（之前就因为这个误导过）。
    try:
        import elements as EL
    except ModuleNotFoundError as exc:
        if exc.name == 'elements':
            raise RuntimeError('找不到 elements.py —— 它应该和 caption.py 放在同一个文件夹里')
        raise RuntimeError('elements.py 需要的模块没装：%s（本工具只需要 Pillow）' % exc.name)
    except ImportError as exc:
        raise RuntimeError('elements.py 导入失败：%s' % exc)

    def g(key, default=None):
        return opts.get(key, default)

    with Image.open(src) as im:
        W, H = im.size
    rng = random.Random(g('seed'))
    prompt, meta = read_prompt(src), read_meta(src)
    texts = pre.get('texts') or {}

    # 取值优先级：显式参数 → PNG 元数据 → 解析提示词 → 预设默认值
    title = (g('title') if g('title') is not None
             else (meta.get('title') or guess_title(prompt))).upper()
    name = (g('name') if g('name') is not None
            else (meta.get('name') or guess_name(prompt) or title))
    item = (g('item') if g('item') is not None
            else (meta.get('item') or guess_item(prompt) or texts.get('item_fallback', '')))

    ink = g('ink') or pre['palette']['ink']
    bg = g('bg') or pre['palette']['bg']
    n_col = int((pre.get('palette') or {}).get('count', 4))      # 配色数量由预设自己定
    colors = g('colors')
    cols = ([c.strip() for c in colors.split(',') if c.strip()] if isinstance(colors, str)
            else list(colors) if colors else [])
    if not cols:
        cols = extract_colors(src, n_col)
    if not re.fullmatch(r'#[0-9a-fA-F]{6}', ink) or any(not re.fullmatch(r'#[0-9a-fA-F]{6}', c) for c in cols):
        raise ValueError('配色请使用 #RRGGBB 格式')
    while len(cols) < 4:
        cols.append('#8fa8c4')

    base_im = Image.open(src).convert('RGB')
    base_im.load()

    def edge_median(img):
        """四边像素的中位数当背景色。只用 Pillow。"""
        w, h = img.size
        px = (list(img.crop((0, 0, w, 1)).getdata())
              + list(img.crop((0, h - 1, w, h)).getdata())
              + list(img.crop((0, 0, 1, h)).getdata())
              + list(img.crop((w - 1, 0, w, h)).getdata()))
        return [statistics.median(c[i] for c in px) for i in range(3)]

    bg_rgb = edge_median(base_im.resize((160, max(8, int(160 * H / W))), Image.LANCZOS))

    def sample(box):
        """取某个像素框里的底色中位数（逐块取色用）。只用 Pillow。"""
        if not box:
            return None
        x, y, w, h = (int(round(v)) for v in box)
        x0, y0 = max(0, min(W - 1, x)), max(0, min(H - 1, y))
        x1, y1 = max(x0 + 1, min(W, x + w)), max(y0 + 1, min(H, y + h))
        crop = base_im.crop((x0, y0, x1, y1))
        crop.thumbnail((64, 64), Image.LANCZOS)
        return list(ImageStat.Stat(crop).median)

    tokens = {'title': title, 'name': name, 'item': item,
              'item2': g('item2') if g('item2') is not None else texts.get('item2', ''),
              'brand': g('brand') if g('brand') is not None else texts.get('brand', ''),
              'kicker': g('kicker') if g('kicker') is not None else texts.get('kicker', ''),
              'issue': g('issue') if g('issue') is not None else texts.get('issue', ''),
              'year': g('year') if g('year') is not None else texts.get('year', ''),
              'foot': g('foot') if g('foot') is not None else texts.get('foot', ''),
              'ink': ink, 'bg': bg,
              'bg_rgb': '%d,%d,%d' % tuple(int(bg[i:i + 2], 16) for i in (1, 3, 5))}

    def subst(s):
        return re.sub(r'\{([a-z0-9_]+)\}',
                      lambda m: str(tokens.get(m.group(1), m.group(0))), str(s))

    img_src = g('img_src')
    if img_src is None:
        img_src = 'data:image/png;base64,' + base64.b64encode(Path(src).read_bytes()).decode()

    pbox = person_bbox(src)          # 人物包围盒（装饰避障用）

    def decor_fn(el, ctx):
        """把老的装饰生成器接进元件表：元件只描述「要几种、取什么色」。"""
        dpre = pre.get('decor') or {}
        pool = el.get('pool')
        cnt = el.get('count') or [4, 7]
        lines = list(pool or dpre.get('line') or [])
        shapes = list(pool or dpre.get('shape') or [])
        if pool:                                   # 指定池子时按已知 id 拆成线/形
            known_line = {'hatch', 'vline', 'hline', 'wave', 'curve', 'dash', 'arc2'}
            lines = [x for x in pool if x in known_line]
            shapes = [x for x in pool if x not in known_line]
        css, html, _b = build_decor(ctx['rng'], W, H, ink, cols, 1.0,
                                    extra_obstacles=ctx.get('obstacles') or [],
                                    person_box=pbox,
                                    n_line=tuple(cnt), n_shape=tuple(cnt),
                                    n_bands=tuple(el.get('bands') or (0, 0)),
                                    line_names=lines, shape_names=shapes,
                                    decor_color=el.get('color', dpre.get('color', 'person')))
        return css, html

    def bands_fn(el, ctx):
        """只出斜色带（z 要排在标题之前，否则会盖在字上）。

        ⚠️ build_decor 的第三个返回值是**参数列表** [(top, hgt, ang, op), ...]，不是 HTML。
        老模板在 build_page 里自己把它转成 CSS（见下方 band_css 那段），元件表路径原来
        漏了这一步 —— 而这里线条/几何都设成 (0, 0)，前两个返回值本来就是空的，
        于是这个元件什么都不输出，**斜色带完全不显示**（2026-10-12 用户发现）。
        """
        _c, _h, bands = build_decor(ctx['rng'], W, H, ink, cols, 1.0,
                                    person_box=pbox, n_line=(0, 0), n_shape=(0, 0),
                                    n_bands=tuple(el.get('count') or (2, 4)))
        prefix = el.get('id') or 'band'      # 用元件 id 当前缀，避免多个 bands 元件撞名
        css, html = [], []
        for i, (top, hgt, ang, op) in enumerate(bands, 1):
            css.append('.%s%d{position:absolute; left:-140px; top:%dpx; width:%dpx; height:%dpx;'
                       'background:%s; opacity:%s; transform:rotate(%ddeg);}'
                       % (prefix, i, top, W + 280, hgt, ink, op, ang))
            html.append('<div class="%s%d"></div>' % (prefix, i))
        return '\n'.join(css), '\n'.join(html)

    def title_fn(el, ctx):
        """标题：区域池 / 样式池 / 字号曲线都写在预设里，内部复用老算法（观感不变）。"""
        css, html, box = build_title(ctx['rng'], W, H,
                                     ctx['subst'](el.get('content') or '{title}'),
                                     ink, cols,
                                     tsize=el.get('tsize'),
                                     toff=el.get('toff', 0), toffx=el.get('toffx', 0),
                                     zone=el.get('zone'), zones=el.get('zones'),
                                     styles=el.get('styles'), size_ratios=el.get('size'))
        if box:
            ctx.setdefault('obstacles', []).append(box)     # 让装饰避开标题
        return css, html

    ctx = {'W': W, 'H': H, 'img_src': img_src,
           # 抠图：命令行给了 --cutout，或预设自己声明了 "cutout": true，任一即开
           'cutout_uri': mask_data_uri(src) if (g('cutout') or pre.get('cutout')) else None,
           'colors': cols, 'ink': ink, 'bg_rgb': bg_rgb,
           'sample': sample, 'subst': subst, 'rng': rng,
           'decor_fn': decor_fn, 'bands_fn': bands_fn, 'title_fn': title_fn,
           'obstacles': [],                              # 标题占位，供装饰避让
           'switches': pre.get('switches') or {}}      # 预设声明的开关（供 when 配对用）
    css, body = EL.render(pre['elements'], ctx, overrides=g('overrides'))
    html = EL.page(css, body, W, H, bg)
    return html, W, H, {'title': title, 'name': name, 'colors': cols[:4],
                        'preset': pre.get('id', DEFAULT_PRESET)}


def build_page(src, **opts):
    """生成排版 HTML（不截图）。返回 (html, W, H, meta)。

    预览与正式出图共用这一个函数 → 算法只有一份，预览即所得。
    img_src 为 None 时把原图内嵌成 base64（自包含），否则用给定的图片地址。
    """
    unknown = set(opts) - PAGE_OPTIONS
    if unknown:
        raise TypeError('未知参数：%s' % ', '.join(sorted(unknown)))

    def g(key, default=None):
        return opts.get(key, default)

    pre = load_preset(g('preset'))          # 预设：文案 / 标题样式 / 装饰库 / 固定元件
    if pre.get('elements'):
        return build_elements_page(src, pre, opts)   # 元件表路径（与老模板完全独立）
    texts, palette = pre['texts'], pre['palette']
    ddef = pre['decor'].get('defaults') or {}

    title, name, item = g('title'), g('name'), g('item')
    item2, brand, kicker = g('item2'), g('brand'), g('kicker')
    issue, year, foot = g('issue'), g('year'), g('foot')
    ink, colors, seed = g('ink'), g('colors'), g('seed')
    density = g('density')
    n_line, n_shape = g('n_line'), g('n_shape')
    pad, edge, row_boost = g('pad'), g('edge'), g('row_boost')
    n_bands, lw, tsize = g('n_bands'), g('lw'), g('tsize')
    toff, toffx, zone = g('toff', 0), g('toffx', 0), g('zone')
    font, dscale, dalpha = g('font'), g('dscale', 1.0), g('dalpha', 1.0)
    grid, safe, gap = g('grid'), g('safe', 0.16), g('gap', 14)
    img_src, bg = g('img_src'), g('bg') or palette['bg']

    rng = random.Random(seed)
    with Image.open(src) as im:
        W, H = im.size
    prompt = read_prompt(src)
    meta = read_meta(src)          # 出图时写入的角色信息（老图为空 → 回退解析提示词）

    # 取值优先级：调用方显式传入 → PNG 元数据 → 解析提示词 → 预设默认值
    title = (title if title is not None
             else (meta.get('title') or guess_title(prompt))).upper()
    name = (name if name is not None
            else (meta.get('name') or guess_name(prompt) or title))
    item = (item if item is not None
            else (meta.get('item') or guess_item(prompt) or texts['item_fallback']))
    item2 = texts['item2'] if item2 is None else item2
    brand = texts['brand'] if brand is None else brand
    kicker = texts['kicker'] if kicker is None else kicker
    issue = texts['issue'] if issue is None else issue
    year = texts['year'] if year is None else year
    foot = texts['foot'] if foot is None else foot
    ink = ink or palette['ink']
    font = font or pre['title']['font']
    if density is None:
        density = ddef.get('density', 1.0)
    # colors 接受三种写法：'#a,#b' 字符串 / 颜色列表 / 空（空则自动从画面提取）
    cols = [c.strip() for c in colors.split(',') if c.strip()] if isinstance(colors, str) \
        else list(colors) if colors else []
    if not cols:
        cols = extract_colors(src, 4)
    if not re.fullmatch(r'#[0-9a-fA-F]{6}', ink) or any(not re.fullmatch(r'#[0-9a-fA-F]{6}', c) for c in cols):
        raise ValueError('配色请使用 #RRGGBB 格式')
    while len(cols) < 4:
        cols.append('#8fa8c4')

    # 先生成标题（拿到占位矩形），再生成装饰 —— 标题也计入避障与密度
    title_css, title_html, title_box = build_title(
        rng, W, H, title, ink, cols, tsize=tsize, toff=toff, toffx=toffx, zone=zone,
        zones=pre['title']['zones'], styles=pre['title']['styles'],
        size_ratios=pre['title']['size'])
    pbox = person_bbox(src)          # 颜色识别出的人物包围盒（避障用）
    decor_css, decor_html, bands = build_decor(
        rng, W, H, ink, cols, density,
        extra_obstacles=[title_box] if title_box else [], person_box=pbox,
        n_line=n_line or tuple(ddef.get('n_line', (4, 7))),
        n_shape=n_shape or tuple(ddef.get('n_shape', (6, 10))),
        pad=20 if pad is None else pad, edge=edge,
        row_boost=1.55 if row_boost is None else row_boost,
        n_bands=n_bands or tuple(ddef.get('bands', (2, 4))),
        lw=ddef.get('lw', 4) if lw is None else lw,
        dscale=dscale, dalpha=dalpha, grid=grid or (4, 5), safe=safe, gap=gap,
        line_names=pre['decor']['line'], shape_names=pre['decor']['shape'],
        decor_color=pre['decor']['color'])
    band_css, band_html = [], []
    for i, (top, hgt, ang, op) in enumerate(bands, 1):
        band_css.append('.band%d{position:absolute; left:-140px; top:%dpx; width:%dpx; height:%dpx;'
                        'background:%s; opacity:%s; transform:rotate(%ddeg);}'
                        % (i, top, W + 280, hgt, ink, op, ang))
        band_html.append('<div class="band%d"></div>' % i)

    if not re.fullmatch(r'#[0-9a-fA-F]{6}', bg):
        raise ValueError('背景色请使用 #RRGGBB 格式')
    veil = '%d,%d,%d' % tuple(int(bg[i:i + 2], 16) for i in (1, 3, 5))
    stack = SERIF_STACKS.get((font or 'georgia').lower(), SERIF_STACKS['georgia'])
    if img_src is None:
        mime = 'image/jpeg' if src.lower().endswith(('.jpg', '.jpeg')) else 'image/png'
        img_src = 'data:%s;base64,%s' % (mime, base64.b64encode(Path(src).read_bytes()).decode())

    # 固定元件：由预设的 chrome 开关决定保留哪些（模板里对应 __CHROME_xxx__ 占位符）
    ch = pre['chrome']

    def on(key):
        return ch.get(key, True)

    chrome = {
        '__CHROME_VEIL__': '<div class="veil-bottom"></div>' if on('veil') else '',
        '__CHROME_BAR__': '<div class="bar"></div>' if on('bar') else '',
        '__CHROME_BOTBAR__': '<div class="botbar"></div>' if on('botbar') else '',
        '__CHROME_TOP__': ('<div class="top ink sans"><div class="brand">%s</div>'
                           '<div class="rule"></div></div>' % escape(brand)) if on('top') else '',
        '__CHROME_KICKER__': ('<div class="kicker ink sans">%s</div>' % escape(kicker)) if on('kicker') else '',
        '__CHROME_SWATCHES__': ('<div class="swatch sw1"></div><div class="swatch sw2"></div>'
                                '<div class="swatch sw3"></div><div class="swatch sw4"></div>'
                                ) if on('swatches') else '',
        '__CHROME_INFO__': ('<div class="info ink"><div class="rule2"></div>'
                            '<div class="item serif">%s</div><div class="item2 sans">%s</div>'
                            '<div class="item2 sans">%s</div></div>'
                            % (escape(item), escape(name), escape(item2))) if on('info') else '',
        '__CHROME_ISSUE__': ('<div class="issue ink"><div class="no serif">%s</div>'
                             '<div class="yr sans">%s</div></div>'
                             % (escape(issue), escape(year))) if on('issue') else '',
        '__CHROME_FOOTLINE__': ('<div class="footline ink sans">%s</div>'
                                % escape(foot)) if on('footline') else '',
    }

    # 抠图分层：把人物单独抠出来叠在**最上层**，文字就「垫到人物下面」—— VOGUE 式层次。
    # 关掉时两个占位符都是空串，生成的 HTML 与从前逐字一致（不影响预设 1）。
    if g('cutout'):
        uri = mask_data_uri(src)
        cut_css = ('.cutout { position:absolute; left:0; top:0; width:%dpx; height:%dpx;'
                   ' -webkit-mask-image:url(%s); -webkit-mask-size:100%% 100%%;'
                   ' mask-image:url(%s); mask-size:100%% 100%%; }' % (W, H, uri, uri))
        cut_html = '<img class="art cutout" src="%s">' % img_src
    else:
        cut_css = cut_html = ''

    html = pre.get('template') or TPL
    rep = {
        '__CUTOUT_CSS__': cut_css, '__CUTOUT_HTML__': cut_html,
        '__W__': str(W), '__H__': str(H), '__IMG_SRC__': img_src,
        '__BG__': bg, '__VEIL_RGB__': veil, '__SERIF__': stack,
        '__NAME__': escape(name), '__ITEM__': escape(item), '__ITEM2__': escape(item2), '__BRAND__': escape(brand),
        '__KICKER__': escape(kicker), '__ISSUE__': escape(issue), '__YEAR__': escape(year), '__FOOT__': escape(foot), '__INK__': ink,
        '__C1__': cols[0], '__C2__': cols[1], '__C3__': cols[2], '__C4__': cols[3],
        '__BAND_CSS__': '\n'.join(band_css), '__BAND_HTML__': '\n'.join(band_html),
        '__TITLE_CSS__': title_css, '__TITLE_HTML__': title_html,
        '__DECOR_CSS__': decor_css, '__DECOR_HTML__': decor_html,
    }
    rep.update(chrome)
    for key, value in rep.items():
        html = html.replace(key, value)
    return html, W, H, {'title': title, 'name': name, 'colors': cols[:4],
                        'preset': pre.get('id', DEFAULT_PRESET)}


def shoot(html_path, out, W, H):
    """用无头浏览器把 HTML 截成 PNG；失败就抛异常，绝不留下旧图冒充成功。"""
    browser = find_browser()
    if not os.path.isfile(browser):
        raise RuntimeError('未找到 Edge / Chrome，无法导出图片（当前尝试路径：%s）' % browser)
    # 独立浏览器目录与新输出路径，截图失败时绝不把旧图当成功。
    with tempfile.TemporaryDirectory(prefix='caption_edge_') as profile:
        fresh = os.path.join(profile, 'shot.png')
        proc = subprocess.run([browser, '--headless=new', '--disable-gpu', '--hide-scrollbars',
                               '--no-first-run', '--force-device-scale-factor=1',
                               '--user-data-dir=' + profile, '--screenshot=' + fresh,
                               '--window-size=%d,%d' % (W, H), Path(html_path).as_uri()],
                              capture_output=True, timeout=90)
        if proc.returncode != 0 or not os.path.isfile(fresh):
            detail = proc.stderr.decode('utf-8', errors='replace')[-500:]
            raise RuntimeError('图片导出失败，未生成新截图：' + detail)
        with Image.open(fresh) as screenshot:
            screenshot.load()
            if screenshot.size != (W, H):
                raise RuntimeError('导出图片尺寸与原图不一致')
        os.replace(fresh, out)


def render(src, out, **opts):
    """生成 HTML → 写同名 .html → 无头截图成 PNG。返回 out。"""
    out = os.path.abspath(out)
    html, W, H, meta = build_page(src, **opts)
    hp = os.path.splitext(out)[0] + '.html'
    with open(hp, 'w', encoding='utf-8') as f:
        f.write(html)
    shoot(hp, out, W, H)
    print('[标题] %s' % meta['title'])
    print('[角色] %s' % meta['name'])
    print('[配色] %s' % ', '.join(meta['colors']))
    print('[%s] %s' % ('OK' if os.path.exists(out) else 'FAIL', out))
    return out


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('src')
    ap.add_argument('--out')
    ap.add_argument('--title'); ap.add_argument('--name'); ap.add_argument('--item')
    ap.add_argument('--item2'); ap.add_argument('--brand'); ap.add_argument('--kicker')
    ap.add_argument('--issue'); ap.add_argument('--year'); ap.add_argument('--foot')
    ap.add_argument('--ink'); ap.add_argument('--colors'); ap.add_argument('--seed', type=int)
    ap.add_argument('--density', type=float, default=1.0)
    ap.add_argument('--count', type=int, default=1, help='一次生成张数（1~10）')
    ap.add_argument('--nline', type=int, nargs=2, metavar=('MIN', 'MAX'))
    ap.add_argument('--nshape', type=int, nargs=2, metavar=('MIN', 'MAX'))
    ap.add_argument('--pad', type=float); ap.add_argument('--edge', type=float)
    ap.add_argument('--rowboost', type=float); ap.add_argument('--bands', type=int)
    ap.add_argument('--lw', type=int); ap.add_argument('--tsize', type=int)
    ap.add_argument('--toff', type=float, default=0); ap.add_argument('--toffx', type=float, default=0)
    ap.add_argument('--zone', choices=['left', 'right', 'bottom', 'leftbottom'])
    ap.add_argument('--font', choices=sorted(SERIF_STACKS))
    ap.add_argument('--preset', choices=[item['id'] for item in list_presets()],
                    help='风格预设（见 presets 文件夹）')
    ap.add_argument('--dscale', type=float, help='装饰尺寸倍率，默认 1.0')
    ap.add_argument('--dalpha', type=float, help='装饰透明度倍率，默认 1.0')
    ap.add_argument('--grid', type=int, nargs=2, metavar=('COLS', 'ROWS'))
    ap.add_argument('--safe', type=float, help='上下安全区比例，默认 0.16')
    ap.add_argument('--gap', type=float, help='装饰最小间距 px，默认 14')
    ap.add_argument('--bg', help='背景色 #RRGGBB，默认 #e9dfcb')
    ap.add_argument('--tag-meta', action='store_true',
                    help='只给这张图补写标题元数据，不排版（给老图补标记用）')
    ap.add_argument('--cutout', action='store_true',
                    help='抠出人物叠在最上层（文字垫到人物下面）')
    a = ap.parse_args()
    if a.tag_meta:
        meta = tag_meta_from_prompt(a.src, a.title, a.name)
        print('[元数据] %s = %s / %s' % (META_KEY, meta['title'], meta['name']))
        raise SystemExit(0)
    if not 1 <= a.count <= 20:
        ap.error('--count 必须在 1~20 之间')
    out = a.out or os.path.join(HERE, os.path.splitext(os.path.basename(a.src))[0] + '_cap.png')
    for i in range(a.count):
        dest = out if a.count == 1 else os.path.splitext(out)[0] + '_%02d.png' % (i + 1)
        render(a.src, dest, title=a.title, name=a.name, item=a.item, item2=a.item2,
               brand=a.brand, kicker=a.kicker, issue=a.issue, year=a.year, foot=a.foot,
               ink=a.ink, colors=a.colors,
               seed=None if a.seed is None else a.seed + i, density=a.density,
               n_line=a.nline, n_shape=a.nshape, pad=a.pad, edge=a.edge,
               row_boost=a.rowboost, n_bands=None if a.bands is None else (a.bands, a.bands),
               lw=a.lw, tsize=a.tsize, toff=a.toff, toffx=a.toffx, zone=a.zone,
               font=a.font, dscale=1.0 if a.dscale is None else a.dscale,
               dalpha=1.0 if a.dalpha is None else a.dalpha, grid=a.grid,
               safe=0.16 if a.safe is None else a.safe, gap=14 if a.gap is None else a.gap,
               bg=a.bg, preset=a.preset, cutout=a.cutout)

' Launch serve.py with no visible window, then exit immediately.
' Called by the start script; reads CAPTION_PY and CAPTION_PORT from the
' environment so that quoting of paths with spaces stays simple.
Option Explicit

Dim fso, sh, base, py, port, cmd
Set fso = CreateObject("Scripting.FileSystemObject")
Set sh  = CreateObject("WScript.Shell")

base = fso.GetParentFolderName(WScript.ScriptFullName)
py   = sh.ExpandEnvironmentStrings("%CAPTION_PY%")
port = sh.ExpandEnvironmentStrings("%CAPTION_PORT%")
If py   = "" Then py   = "python"
If port = "" Then port = "8801"

sh.CurrentDirectory = base
cmd = py & " """ & base & "\serve.py"" " & port

' 0 = hidden window, False = do not wait for it to finish
sh.Run cmd, 0, False
